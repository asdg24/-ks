﻿public enum HypeSquad
{
    Balance, Bravery, Brilliance
}