﻿public enum UserStatus
{
    Online, Idle, DoNotDisturb, Invisible
}