﻿partial class MainForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.gunaControlBox1 = new Guna.UI.WinForms.GunaControlBox();
            this.gunaControlBox2 = new Guna.UI.WinForms.GunaControlBox();
            this.gunaControlBox3 = new Guna.UI.WinForms.GunaControlBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.firefoxMainTabControl1 = new FirefoxMainTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.siticoneCheckBox37 = new ns1.SiticoneCheckBox();
            this.gunaLineTextBox23 = new Guna.UI.WinForms.GunaLineTextBox();
            this.siticoneCheckBox23 = new ns1.SiticoneCheckBox();
            this.siticoneButton6 = new ns1.SiticoneButton();
            this.siticoneButton5 = new ns1.SiticoneButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.siticoneButton3 = new ns1.SiticoneButton();
            this.metroLabel15 = new MetroSuite.MetroLabel();
            this.metroLabel16 = new MetroSuite.MetroLabel();
            this.siticoneButton4 = new ns1.SiticoneButton();
            this.siticoneButton2 = new ns1.SiticoneButton();
            this.metroLabel14 = new MetroSuite.MetroLabel();
            this.metroLabel13 = new MetroSuite.MetroLabel();
            this.siticoneButton1 = new ns1.SiticoneButton();
            this.metroLabel1 = new MetroSuite.MetroLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.siticoneCheckBox36 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox33 = new ns1.SiticoneCheckBox();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.metroLabel17 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith1 = new ns1.SiticoneOSToggleSwith();
            this.siticoneCheckBox4 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox3 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox2 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox1 = new ns1.SiticoneCheckBox();
            this.gunaLineTextBox3 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox2 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox1 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel2 = new MetroSuite.MetroLabel();
            this.bunifuHSlider1 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.siticoneCheckBox34 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox29 = new ns1.SiticoneCheckBox();
            this.siticoneRadioButton5 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton4 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton3 = new ns1.SiticoneRadioButton();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.metroLabel18 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith2 = new ns1.SiticoneOSToggleSwith();
            this.siticoneCheckBox9 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox8 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox7 = new ns1.SiticoneCheckBox();
            this.gunaTextBox1 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLineTextBox5 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox4 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel3 = new MetroSuite.MetroLabel();
            this.bunifuHSlider2 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.siticoneRadioButton6 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton7 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton8 = new ns1.SiticoneRadioButton();
            this.metroLabel19 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith3 = new ns1.SiticoneOSToggleSwith();
            this.gunaButton6 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton5 = new Guna.UI.WinForms.GunaButton();
            this.siticoneCheckBox12 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox11 = new ns1.SiticoneCheckBox();
            this.gunaTextBox2 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLineTextBox7 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox6 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel4 = new MetroSuite.MetroLabel();
            this.bunifuHSlider3 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.siticoneButton7 = new ns1.SiticoneButton();
            this.gunaButton8 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton7 = new Guna.UI.WinForms.GunaButton();
            this.metroLabel20 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith4 = new ns1.SiticoneOSToggleSwith();
            this.siticoneRadioButton2 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton1 = new ns1.SiticoneRadioButton();
            this.gunaLineTextBox10 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox9 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox8 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel5 = new MetroSuite.MetroLabel();
            this.bunifuHSlider4 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.siticoneCheckBox35 = new ns1.SiticoneCheckBox();
            this.bunifuHSlider5 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.gunaButton9 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton10 = new Guna.UI.WinForms.GunaButton();
            this.metroLabel21 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith5 = new ns1.SiticoneOSToggleSwith();
            this.siticoneCheckBox5 = new ns1.SiticoneCheckBox();
            this.gunaLineTextBox11 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel6 = new MetroSuite.MetroLabel();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.bunifuHSlider6 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.gunaButton12 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton11 = new Guna.UI.WinForms.GunaButton();
            this.metroLabel22 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith6 = new ns1.SiticoneOSToggleSwith();
            this.siticoneCheckBox13 = new ns1.SiticoneCheckBox();
            this.gunaLineTextBox12 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel7 = new MetroSuite.MetroLabel();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.gunaLineTextBox16 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaButton16 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton15 = new Guna.UI.WinForms.GunaButton();
            this.siticoneCheckBox21 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox20 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox19 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox18 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox17 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox16 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox15 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox14 = new ns1.SiticoneCheckBox();
            this.metroLabel26 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith10 = new ns1.SiticoneOSToggleSwith();
            this.metroLabel25 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith9 = new ns1.SiticoneOSToggleSwith();
            this.gunaLineTextBox15 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox14 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel9 = new MetroSuite.MetroLabel();
            this.bunifuHSlider10 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.bunifuHSlider9 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.siticoneRadioButton9 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton10 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton11 = new ns1.SiticoneRadioButton();
            this.siticoneCheckBox27 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox22 = new ns1.SiticoneCheckBox();
            this.gunaButton18 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton17 = new Guna.UI.WinForms.GunaButton();
            this.metroLabel27 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith11 = new ns1.SiticoneOSToggleSwith();
            this.gunaTextBox3 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLineTextBox19 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox18 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox17 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel10 = new MetroSuite.MetroLabel();
            this.bunifuHSlider11 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.siticoneCheckBox28 = new ns1.SiticoneCheckBox();
            this.metroLabel8 = new MetroSuite.MetroLabel();
            this.gunaButton20 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton19 = new Guna.UI.WinForms.GunaButton();
            this.metroLabel28 = new MetroSuite.MetroLabel();
            this.siticoneOSToggleSwith12 = new ns1.SiticoneOSToggleSwith();
            this.gunaTextBox4 = new Guna.UI.WinForms.GunaTextBox();
            this.metroLabel11 = new MetroSuite.MetroLabel();
            this.bunifuHSlider12 = new Bunifu.UI.WinForms.BunifuHSlider();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.siticoneCheckBox32 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox31 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox30 = new ns1.SiticoneCheckBox();
            this.siticoneComboBox1 = new ns1.SiticoneComboBox();
            this.siticoneButton9 = new ns1.SiticoneButton();
            this.siticoneCheckBox26 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox25 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox24 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox10 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox6 = new ns1.SiticoneCheckBox();
            this.gunaLineTextBox13 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaTextBox5 = new Guna.UI.WinForms.GunaTextBox();
            this.siticoneButton12 = new ns1.SiticoneButton();
            this.siticoneComboBox2 = new ns1.SiticoneComboBox();
            this.siticoneButton11 = new ns1.SiticoneButton();
            this.siticoneButton8 = new ns1.SiticoneButton();
            this.gunaLineTextBox22 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox21 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLinkLabel1 = new Guna.UI.WinForms.GunaLinkLabel();
            this.gunaLineTextBox20 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel12 = new MetroSuite.MetroLabel();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.siticoneButton23 = new ns1.SiticoneButton();
            this.siticoneButton22 = new ns1.SiticoneButton();
            this.siticoneButton21 = new ns1.SiticoneButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.siticoneButton20 = new ns1.SiticoneButton();
            this.gunaLineTextBox29 = new Guna.UI.WinForms.GunaLineTextBox();
            this.siticoneButton19 = new ns1.SiticoneButton();
            this.gunaLineTextBox28 = new Guna.UI.WinForms.GunaLineTextBox();
            this.siticoneButton18 = new ns1.SiticoneButton();
            this.siticoneButton15 = new ns1.SiticoneButton();
            this.siticoneButton16 = new ns1.SiticoneButton();
            this.metroLabel33 = new MetroSuite.MetroLabel();
            this.metroLabel34 = new MetroSuite.MetroLabel();
            this.siticoneButton17 = new ns1.SiticoneButton();
            this.gunaLineTextBox27 = new Guna.UI.WinForms.GunaLineTextBox();
            this.siticoneButton14 = new ns1.SiticoneButton();
            this.siticoneButton13 = new ns1.SiticoneButton();
            this.metroLabel32 = new MetroSuite.MetroLabel();
            this.metroLabel31 = new MetroSuite.MetroLabel();
            this.siticoneButton10 = new ns1.SiticoneButton();
            this.gunaLineTextBox24 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox25 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel29 = new MetroSuite.MetroLabel();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.metroLabel24 = new MetroSuite.MetroLabel();
            this.openFileDialog3 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog4 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.saveFileDialog2 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog5 = new System.Windows.Forms.OpenFileDialog();
            this.firefoxMainTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage13.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaControlBox1
            // 
            this.gunaControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox1.Animated = true;
            this.gunaControlBox1.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox1.AnimationSpeed = 0.03F;
            this.gunaControlBox1.IconColor = System.Drawing.Color.White;
            this.gunaControlBox1.IconSize = 15F;
            this.gunaControlBox1.Location = new System.Drawing.Point(1072, 7);
            this.gunaControlBox1.Name = "gunaControlBox1";
            this.gunaControlBox1.OnHoverBackColor = System.Drawing.Color.Red;
            this.gunaControlBox1.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox1.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox1.TabIndex = 0;
            // 
            // gunaControlBox2
            // 
            this.gunaControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox2.Animated = true;
            this.gunaControlBox2.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox2.AnimationSpeed = 0.03F;
            this.gunaControlBox2.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MaximizeBox;
            this.gunaControlBox2.IconColor = System.Drawing.Color.White;
            this.gunaControlBox2.IconSize = 15F;
            this.gunaControlBox2.Location = new System.Drawing.Point(1021, 7);
            this.gunaControlBox2.Name = "gunaControlBox2";
            this.gunaControlBox2.OnHoverBackColor = System.Drawing.Color.Red;
            this.gunaControlBox2.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox2.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox2.TabIndex = 1;
            // 
            // gunaControlBox3
            // 
            this.gunaControlBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox3.Animated = true;
            this.gunaControlBox3.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox3.AnimationSpeed = 0.03F;
            this.gunaControlBox3.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MinimizeBox;
            this.gunaControlBox3.IconColor = System.Drawing.Color.White;
            this.gunaControlBox3.IconSize = 15F;
            this.gunaControlBox3.Location = new System.Drawing.Point(970, 7);
            this.gunaControlBox3.Name = "gunaControlBox3";
            this.gunaControlBox3.OnHoverBackColor = System.Drawing.Color.Red;
            this.gunaControlBox3.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox3.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox3.TabIndex = 2;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Text file (*.txt)|*.txt";
            this.openFileDialog1.Multiselect = true;
            this.openFileDialog1.Title = "Load tokens from file";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.Filter = "Text file (*.txt)|*.txt";
            this.openFileDialog2.Multiselect = true;
            this.openFileDialog2.Title = "Load proxies from file";
            // 
            // firefoxMainTabControl1
            // 
            this.firefoxMainTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.firefoxMainTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.firefoxMainTabControl1.Controls.Add(this.tabPage1);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage2);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage3);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage4);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage5);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage6);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage7);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage9);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage10);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage11);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage12);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage8);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage13);
            this.firefoxMainTabControl1.ItemSize = new System.Drawing.Size(43, 180);
            this.firefoxMainTabControl1.Location = new System.Drawing.Point(1, 42);
            this.firefoxMainTabControl1.Multiline = true;
            this.firefoxMainTabControl1.Name = "firefoxMainTabControl1";
            this.firefoxMainTabControl1.SelectedIndex = 0;
            this.firefoxMainTabControl1.Size = new System.Drawing.Size(1119, 589);
            this.firefoxMainTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.firefoxMainTabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage1.Controls.Add(this.siticoneCheckBox37);
            this.tabPage1.Controls.Add(this.gunaLineTextBox23);
            this.tabPage1.Controls.Add(this.siticoneCheckBox23);
            this.tabPage1.Controls.Add(this.siticoneButton6);
            this.tabPage1.Controls.Add(this.siticoneButton5);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.siticoneButton3);
            this.tabPage1.Controls.Add(this.metroLabel15);
            this.tabPage1.Controls.Add(this.metroLabel16);
            this.tabPage1.Controls.Add(this.siticoneButton4);
            this.tabPage1.Controls.Add(this.siticoneButton2);
            this.tabPage1.Controls.Add(this.metroLabel14);
            this.tabPage1.Controls.Add(this.metroLabel13);
            this.tabPage1.Controls.Add(this.siticoneButton1);
            this.tabPage1.Controls.Add(this.metroLabel1);
            this.tabPage1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage1.Location = new System.Drawing.Point(184, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(931, 581);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Homepage";
            // 
            // siticoneCheckBox37
            // 
            this.siticoneCheckBox37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox37.AutoSize = true;
            this.siticoneCheckBox37.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox37.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox37.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox37.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox37.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox37.Location = new System.Drawing.Point(396, 317);
            this.siticoneCheckBox37.Name = "siticoneCheckBox37";
            this.siticoneCheckBox37.Size = new System.Drawing.Size(145, 17);
            this.siticoneCheckBox37.TabIndex = 53;
            this.siticoneCheckBox37.Text = "Limit number of tokens";
            this.siticoneCheckBox37.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox37.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox37.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox37.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox37.UseVisualStyleBackColor = true;
            // 
            // gunaLineTextBox23
            // 
            this.gunaLineTextBox23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox23.Animated = true;
            this.gunaLineTextBox23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox23.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox23.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox23.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox23.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox23.LineSize = 1;
            this.gunaLineTextBox23.Location = new System.Drawing.Point(383, 281);
            this.gunaLineTextBox23.MaxLength = 2147483647;
            this.gunaLineTextBox23.Name = "gunaLineTextBox23";
            this.gunaLineTextBox23.PasswordChar = '\0';
            this.gunaLineTextBox23.Size = new System.Drawing.Size(167, 26);
            this.gunaLineTextBox23.TabIndex = 52;
            this.gunaLineTextBox23.Text = "0";
            this.gunaLineTextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaLineTextBox23.TextOffsetX = 0;
            // 
            // siticoneCheckBox23
            // 
            this.siticoneCheckBox23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox23.AutoSize = true;
            this.siticoneCheckBox23.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox23.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox23.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox23.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox23.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox23.Location = new System.Drawing.Point(425, 182);
            this.siticoneCheckBox23.Name = "siticoneCheckBox23";
            this.siticoneCheckBox23.Size = new System.Drawing.Size(85, 17);
            this.siticoneCheckBox23.TabIndex = 14;
            this.siticoneCheckBox23.Text = "Use proxies";
            this.siticoneCheckBox23.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox23.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox23.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox23.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox23.UseVisualStyleBackColor = true;
            // 
            // siticoneButton6
            // 
            this.siticoneButton6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton6.BorderRadius = 15;
            this.siticoneButton6.CheckedState.Parent = this.siticoneButton6;
            this.siticoneButton6.CustomImages.Parent = this.siticoneButton6;
            this.siticoneButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton6.ForeColor = System.Drawing.Color.White;
            this.siticoneButton6.HoveredState.Parent = this.siticoneButton6;
            this.siticoneButton6.Location = new System.Drawing.Point(730, 281);
            this.siticoneButton6.Name = "siticoneButton6";
            this.siticoneButton6.ShadowDecoration.Parent = this.siticoneButton6;
            this.siticoneButton6.Size = new System.Drawing.Size(180, 45);
            this.siticoneButton6.TabIndex = 13;
            this.siticoneButton6.Text = "Load Proxies";
            this.siticoneButton6.Click += new System.EventHandler(this.siticoneButton6_Click);
            // 
            // siticoneButton5
            // 
            this.siticoneButton5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton5.BorderRadius = 15;
            this.siticoneButton5.CheckedState.Parent = this.siticoneButton5;
            this.siticoneButton5.CustomImages.Parent = this.siticoneButton5;
            this.siticoneButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton5.ForeColor = System.Drawing.Color.White;
            this.siticoneButton5.HoveredState.Parent = this.siticoneButton5;
            this.siticoneButton5.Location = new System.Drawing.Point(19, 281);
            this.siticoneButton5.Name = "siticoneButton5";
            this.siticoneButton5.ShadowDecoration.Parent = this.siticoneButton5;
            this.siticoneButton5.Size = new System.Drawing.Size(180, 45);
            this.siticoneButton5.TabIndex = 12;
            this.siticoneButton5.Text = "Load Tokens";
            this.siticoneButton5.Click += new System.EventHandler(this.siticoneButton5_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(401, 46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 128);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // siticoneButton3
            // 
            this.siticoneButton3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton3.BorderRadius = 5;
            this.siticoneButton3.CheckedState.Parent = this.siticoneButton3;
            this.siticoneButton3.CustomImages.Parent = this.siticoneButton3;
            this.siticoneButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton3.ForeColor = System.Drawing.Color.White;
            this.siticoneButton3.HoveredState.Parent = this.siticoneButton3;
            this.siticoneButton3.Location = new System.Drawing.Point(730, 148);
            this.siticoneButton3.Name = "siticoneButton3";
            this.siticoneButton3.ShadowDecoration.Parent = this.siticoneButton3;
            this.siticoneButton3.Size = new System.Drawing.Size(180, 45);
            this.siticoneButton3.TabIndex = 8;
            this.siticoneButton3.Text = "Remove dead proxies";
            this.siticoneButton3.Click += new System.EventHandler(this.siticoneButton3_Click);
            // 
            // metroLabel15
            // 
            this.metroLabel15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel15.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel15.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel15.Location = new System.Drawing.Point(727, 64);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(183, 19);
            this.metroLabel15.TabIndex = 7;
            this.metroLabel15.Text = "0";
            this.metroLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel16
            // 
            this.metroLabel16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel16.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel16.Location = new System.Drawing.Point(727, 41);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(183, 19);
            this.metroLabel16.TabIndex = 6;
            this.metroLabel16.Text = "Proxies";
            this.metroLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // siticoneButton4
            // 
            this.siticoneButton4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton4.BorderRadius = 5;
            this.siticoneButton4.CheckedState.Parent = this.siticoneButton4;
            this.siticoneButton4.CustomImages.Parent = this.siticoneButton4;
            this.siticoneButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton4.ForeColor = System.Drawing.Color.White;
            this.siticoneButton4.HoveredState.Parent = this.siticoneButton4;
            this.siticoneButton4.Location = new System.Drawing.Point(730, 97);
            this.siticoneButton4.Name = "siticoneButton4";
            this.siticoneButton4.ShadowDecoration.Parent = this.siticoneButton4;
            this.siticoneButton4.Size = new System.Drawing.Size(180, 45);
            this.siticoneButton4.TabIndex = 5;
            this.siticoneButton4.Text = "Reset Proxies";
            this.siticoneButton4.Click += new System.EventHandler(this.siticoneButton4_Click);
            // 
            // siticoneButton2
            // 
            this.siticoneButton2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton2.BorderRadius = 5;
            this.siticoneButton2.CheckedState.Parent = this.siticoneButton2;
            this.siticoneButton2.CustomImages.Parent = this.siticoneButton2;
            this.siticoneButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton2.ForeColor = System.Drawing.Color.White;
            this.siticoneButton2.HoveredState.Parent = this.siticoneButton2;
            this.siticoneButton2.Location = new System.Drawing.Point(19, 148);
            this.siticoneButton2.Name = "siticoneButton2";
            this.siticoneButton2.ShadowDecoration.Parent = this.siticoneButton2;
            this.siticoneButton2.Size = new System.Drawing.Size(180, 45);
            this.siticoneButton2.TabIndex = 4;
            this.siticoneButton2.Text = "Remove dead tokens";
            this.siticoneButton2.Click += new System.EventHandler(this.siticoneButton2_Click);
            // 
            // metroLabel14
            // 
            this.metroLabel14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel14.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel14.Location = new System.Drawing.Point(16, 64);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(183, 19);
            this.metroLabel14.TabIndex = 3;
            this.metroLabel14.Text = "0";
            this.metroLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel13
            // 
            this.metroLabel13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel13.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel13.Location = new System.Drawing.Point(16, 41);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(183, 19);
            this.metroLabel13.TabIndex = 2;
            this.metroLabel13.Text = "Tokens";
            this.metroLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // siticoneButton1
            // 
            this.siticoneButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton1.BorderRadius = 5;
            this.siticoneButton1.CheckedState.Parent = this.siticoneButton1;
            this.siticoneButton1.CustomImages.Parent = this.siticoneButton1;
            this.siticoneButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton1.ForeColor = System.Drawing.Color.White;
            this.siticoneButton1.HoveredState.Parent = this.siticoneButton1;
            this.siticoneButton1.Location = new System.Drawing.Point(19, 97);
            this.siticoneButton1.Name = "siticoneButton1";
            this.siticoneButton1.ShadowDecoration.Parent = this.siticoneButton1;
            this.siticoneButton1.Size = new System.Drawing.Size(180, 45);
            this.siticoneButton1.TabIndex = 1;
            this.siticoneButton1.Text = "Reset Tokens";
            this.siticoneButton1.Click += new System.EventHandler(this.siticoneButton1_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel1.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel1.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(931, 23);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Homepage";
            this.metroLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage2.Controls.Add(this.siticoneCheckBox36);
            this.tabPage2.Controls.Add(this.siticoneCheckBox33);
            this.tabPage2.Controls.Add(this.gunaButton2);
            this.tabPage2.Controls.Add(this.gunaButton1);
            this.tabPage2.Controls.Add(this.metroLabel17);
            this.tabPage2.Controls.Add(this.siticoneOSToggleSwith1);
            this.tabPage2.Controls.Add(this.siticoneCheckBox4);
            this.tabPage2.Controls.Add(this.siticoneCheckBox3);
            this.tabPage2.Controls.Add(this.siticoneCheckBox2);
            this.tabPage2.Controls.Add(this.siticoneCheckBox1);
            this.tabPage2.Controls.Add(this.gunaLineTextBox3);
            this.tabPage2.Controls.Add(this.gunaLineTextBox2);
            this.tabPage2.Controls.Add(this.gunaLineTextBox1);
            this.tabPage2.Controls.Add(this.metroLabel2);
            this.tabPage2.Controls.Add(this.bunifuHSlider1);
            this.tabPage2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage2.Location = new System.Drawing.Point(184, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(931, 581);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Guild Manager";
            // 
            // siticoneCheckBox36
            // 
            this.siticoneCheckBox36.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox36.AutoSize = true;
            this.siticoneCheckBox36.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox36.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox36.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox36.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox36.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox36.Location = new System.Drawing.Point(144, 354);
            this.siticoneCheckBox36.Name = "siticoneCheckBox36";
            this.siticoneCheckBox36.Size = new System.Drawing.Size(298, 17);
            this.siticoneCheckBox36.TabIndex = 16;
            this.siticoneCheckBox36.Text = "Automatically identify captcha bot challenge channel";
            this.siticoneCheckBox36.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox36.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox36.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox36.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox36.UseVisualStyleBackColor = true;
            this.siticoneCheckBox36.Visible = false;
            // 
            // siticoneCheckBox33
            // 
            this.siticoneCheckBox33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox33.AutoSize = true;
            this.siticoneCheckBox33.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox33.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox33.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox33.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox33.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox33.Location = new System.Drawing.Point(144, 331);
            this.siticoneCheckBox33.Name = "siticoneCheckBox33";
            this.siticoneCheckBox33.Size = new System.Drawing.Size(82, 17);
            this.siticoneCheckBox33.TabIndex = 15;
            this.siticoneCheckBox33.Text = "Raid Mode";
            this.siticoneCheckBox33.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox33.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox33.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox33.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox33.UseVisualStyleBackColor = true;
            this.siticoneCheckBox33.CheckedChanged += new System.EventHandler(this.siticoneCheckBox33_CheckedChanged);
            // 
            // gunaButton2
            // 
            this.gunaButton2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton2.Animated = true;
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton2.Location = new System.Drawing.Point(467, 474);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Size = new System.Drawing.Size(317, 42);
            this.gunaButton2.TabIndex = 13;
            this.gunaButton2.Text = "Leave guild";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // gunaButton1
            // 
            this.gunaButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton1.Animated = true;
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton1.Location = new System.Drawing.Point(144, 474);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Size = new System.Drawing.Size(317, 42);
            this.gunaButton1.TabIndex = 12;
            this.gunaButton1.Text = "Join guild";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // metroLabel17
            // 
            this.metroLabel17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel17.Location = new System.Drawing.Point(721, 239);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(64, 15);
            this.metroLabel17.TabIndex = 11;
            this.metroLabel17.Text = "Delay: 0ms";
            this.metroLabel17.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith1
            // 
            this.siticoneOSToggleSwith1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith1.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith1.Location = new System.Drawing.Point(681, 236);
            this.siticoneOSToggleSwith1.Name = "siticoneOSToggleSwith1";
            this.siticoneOSToggleSwith1.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith1.TabIndex = 10;
            // 
            // siticoneCheckBox4
            // 
            this.siticoneCheckBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox4.AutoSize = true;
            this.siticoneCheckBox4.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox4.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox4.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox4.Location = new System.Drawing.Point(144, 308);
            this.siticoneCheckBox4.Name = "siticoneCheckBox4";
            this.siticoneCheckBox4.Size = new System.Drawing.Size(92, 17);
            this.siticoneCheckBox4.TabIndex = 8;
            this.siticoneCheckBox4.Text = "Group Mode";
            this.siticoneCheckBox4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox4.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox4.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox4.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox4.UseVisualStyleBackColor = true;
            this.siticoneCheckBox4.CheckedChanged += new System.EventHandler(this.siticoneCheckBox4_CheckedChanged);
            // 
            // siticoneCheckBox3
            // 
            this.siticoneCheckBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox3.AutoSize = true;
            this.siticoneCheckBox3.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox3.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox3.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox3.Location = new System.Drawing.Point(144, 285);
            this.siticoneCheckBox3.Name = "siticoneCheckBox3";
            this.siticoneCheckBox3.Size = new System.Drawing.Size(148, 17);
            this.siticoneCheckBox3.TabIndex = 7;
            this.siticoneCheckBox3.Text = "Bypass Text Captcha Bot";
            this.siticoneCheckBox3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox3.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox3.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox3.UseVisualStyleBackColor = true;
            this.siticoneCheckBox3.CheckedChanged += new System.EventHandler(this.siticoneCheckBox3_CheckedChanged);
            // 
            // siticoneCheckBox2
            // 
            this.siticoneCheckBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox2.AutoSize = true;
            this.siticoneCheckBox2.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox2.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox2.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox2.Location = new System.Drawing.Point(144, 262);
            this.siticoneCheckBox2.Name = "siticoneCheckBox2";
            this.siticoneCheckBox2.Size = new System.Drawing.Size(168, 17);
            this.siticoneCheckBox2.TabIndex = 6;
            this.siticoneCheckBox2.Text = "Bypass Reaction verification";
            this.siticoneCheckBox2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox2.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox2.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox2.UseVisualStyleBackColor = true;
            this.siticoneCheckBox2.CheckedChanged += new System.EventHandler(this.siticoneCheckBox2_CheckedChanged);
            // 
            // siticoneCheckBox1
            // 
            this.siticoneCheckBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox1.AutoSize = true;
            this.siticoneCheckBox1.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox1.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox1.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox1.Location = new System.Drawing.Point(144, 239);
            this.siticoneCheckBox1.Name = "siticoneCheckBox1";
            this.siticoneCheckBox1.Size = new System.Drawing.Size(254, 17);
            this.siticoneCheckBox1.TabIndex = 5;
            this.siticoneCheckBox1.Text = "Bypass Discord Community Rules verification";
            this.siticoneCheckBox1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox1.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox1.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox1.UseVisualStyleBackColor = true;
            this.siticoneCheckBox1.CheckedChanged += new System.EventHandler(this.siticoneCheckBox1_CheckedChanged);
            // 
            // gunaLineTextBox3
            // 
            this.gunaLineTextBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox3.Animated = true;
            this.gunaLineTextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox3.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox3.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox3.LineSize = 1;
            this.gunaLineTextBox3.Location = new System.Drawing.Point(144, 192);
            this.gunaLineTextBox3.MaxLength = 2147483647;
            this.gunaLineTextBox3.Name = "gunaLineTextBox3";
            this.gunaLineTextBox3.PasswordChar = '\0';
            this.gunaLineTextBox3.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox3.TabIndex = 4;
            this.gunaLineTextBox3.Text = "Insert the ID of the channel where to send the captcha result here.";
            this.gunaLineTextBox3.TextOffsetX = 0;
            // 
            // gunaLineTextBox2
            // 
            this.gunaLineTextBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox2.Animated = true;
            this.gunaLineTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox2.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox2.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox2.LineSize = 1;
            this.gunaLineTextBox2.Location = new System.Drawing.Point(144, 160);
            this.gunaLineTextBox2.MaxLength = 2147483647;
            this.gunaLineTextBox2.Name = "gunaLineTextBox2";
            this.gunaLineTextBox2.PasswordChar = '\0';
            this.gunaLineTextBox2.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox2.TabIndex = 3;
            this.gunaLineTextBox2.Text = "Insert the captcha bot ID to bypass here.";
            this.gunaLineTextBox2.TextOffsetX = 0;
            // 
            // gunaLineTextBox1
            // 
            this.gunaLineTextBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox1.Animated = true;
            this.gunaLineTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox1.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox1.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox1.LineSize = 1;
            this.gunaLineTextBox1.Location = new System.Drawing.Point(144, 128);
            this.gunaLineTextBox1.MaxLength = 2147483647;
            this.gunaLineTextBox1.Name = "gunaLineTextBox1";
            this.gunaLineTextBox1.PasswordChar = '\0';
            this.gunaLineTextBox1.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox1.TabIndex = 2;
            this.gunaLineTextBox1.Text = "Insert the guild invite link / code / ID here.";
            this.gunaLineTextBox1.TextOffsetX = 0;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel2.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel2.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(931, 23);
            this.metroLabel2.TabIndex = 1;
            this.metroLabel2.Text = "Guild Manager";
            this.metroLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bunifuHSlider1
            // 
            this.bunifuHSlider1.AllowCursorChanges = true;
            this.bunifuHSlider1.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider1.AllowIncrementalClickMoves = true;
            this.bunifuHSlider1.AllowMouseDownEffects = false;
            this.bunifuHSlider1.AllowMouseHoverEffects = false;
            this.bunifuHSlider1.AllowScrollingAnimations = true;
            this.bunifuHSlider1.AllowScrollKeysDetection = true;
            this.bunifuHSlider1.AllowScrollOptionsMenu = true;
            this.bunifuHSlider1.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider1.BackgroundImage")));
            this.bunifuHSlider1.BindingContainer = null;
            this.bunifuHSlider1.BorderRadius = 2;
            this.bunifuHSlider1.BorderThickness = 1;
            this.bunifuHSlider1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider1.DrawThickBorder = false;
            this.bunifuHSlider1.DurationBeforeShrink = 2000;
            this.bunifuHSlider1.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider1.LargeChange = 10;
            this.bunifuHSlider1.Location = new System.Drawing.Point(144, 384);
            this.bunifuHSlider1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuHSlider1.Maximum = 5000;
            this.bunifuHSlider1.Minimum = 0;
            this.bunifuHSlider1.MinimumSize = new System.Drawing.Size(0, 41);
            this.bunifuHSlider1.MinimumThumbLength = 18;
            this.bunifuHSlider1.Name = "bunifuHSlider1";
            this.bunifuHSlider1.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider1.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider1.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider1.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider1.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider1.ShrinkSizeLimit = 3;
            this.bunifuHSlider1.Size = new System.Drawing.Size(641, 41);
            this.bunifuHSlider1.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider1.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider1.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider1.SmallChange = 1;
            this.bunifuHSlider1.TabIndex = 14;
            this.bunifuHSlider1.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider1.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider1.ThumbLength = 18;
            this.bunifuHSlider1.ThumbMargin = 1;
            this.bunifuHSlider1.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider1.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider1.Value = 0;
            this.bunifuHSlider1.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider1_Scroll);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage3.Controls.Add(this.siticoneCheckBox34);
            this.tabPage3.Controls.Add(this.siticoneCheckBox29);
            this.tabPage3.Controls.Add(this.siticoneRadioButton5);
            this.tabPage3.Controls.Add(this.siticoneRadioButton4);
            this.tabPage3.Controls.Add(this.siticoneRadioButton3);
            this.tabPage3.Controls.Add(this.gunaButton3);
            this.tabPage3.Controls.Add(this.gunaButton4);
            this.tabPage3.Controls.Add(this.metroLabel18);
            this.tabPage3.Controls.Add(this.siticoneOSToggleSwith2);
            this.tabPage3.Controls.Add(this.siticoneCheckBox9);
            this.tabPage3.Controls.Add(this.siticoneCheckBox8);
            this.tabPage3.Controls.Add(this.siticoneCheckBox7);
            this.tabPage3.Controls.Add(this.gunaTextBox1);
            this.tabPage3.Controls.Add(this.gunaLineTextBox5);
            this.tabPage3.Controls.Add(this.gunaLineTextBox4);
            this.tabPage3.Controls.Add(this.metroLabel3);
            this.tabPage3.Controls.Add(this.bunifuHSlider2);
            this.tabPage3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage3.Location = new System.Drawing.Point(184, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(931, 581);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Server Spammer";
            // 
            // siticoneCheckBox34
            // 
            this.siticoneCheckBox34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox34.AutoSize = true;
            this.siticoneCheckBox34.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox34.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox34.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox34.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox34.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox34.Location = new System.Drawing.Point(303, 417);
            this.siticoneCheckBox34.Name = "siticoneCheckBox34";
            this.siticoneCheckBox34.Size = new System.Drawing.Size(135, 17);
            this.siticoneCheckBox34.TabIndex = 22;
            this.siticoneCheckBox34.Text = "Auto Delete Message";
            this.siticoneCheckBox34.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox34.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox34.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox34.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox34.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox29
            // 
            this.siticoneCheckBox29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox29.AutoSize = true;
            this.siticoneCheckBox29.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox29.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox29.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox29.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox29.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox29.Location = new System.Drawing.Point(144, 418);
            this.siticoneCheckBox29.Name = "siticoneCheckBox29";
            this.siticoneCheckBox29.Size = new System.Drawing.Size(101, 17);
            this.siticoneCheckBox29.TabIndex = 21;
            this.siticoneCheckBox29.Text = "Roles Mention";
            this.siticoneCheckBox29.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox29.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox29.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox29.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox29.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton5
            // 
            this.siticoneRadioButton5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton5.AutoSize = true;
            this.siticoneRadioButton5.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton5.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton5.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton5.Location = new System.Drawing.Point(303, 394);
            this.siticoneRadioButton5.Name = "siticoneRadioButton5";
            this.siticoneRadioButton5.Size = new System.Drawing.Size(103, 17);
            this.siticoneRadioButton5.TabIndex = 20;
            this.siticoneRadioButton5.Text = "Supreme Mode";
            this.siticoneRadioButton5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton5.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton5.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton5.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton5.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton4
            // 
            this.siticoneRadioButton4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton4.AutoSize = true;
            this.siticoneRadioButton4.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton4.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton4.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton4.Location = new System.Drawing.Point(303, 371);
            this.siticoneRadioButton4.Name = "siticoneRadioButton4";
            this.siticoneRadioButton4.Size = new System.Drawing.Size(98, 17);
            this.siticoneRadioButton4.TabIndex = 19;
            this.siticoneRadioButton4.Text = "Extreme Mode";
            this.siticoneRadioButton4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton4.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton4.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton4.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton4.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton3
            // 
            this.siticoneRadioButton3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton3.AutoSize = true;
            this.siticoneRadioButton3.Checked = true;
            this.siticoneRadioButton3.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton3.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton3.Location = new System.Drawing.Point(303, 349);
            this.siticoneRadioButton3.Name = "siticoneRadioButton3";
            this.siticoneRadioButton3.Size = new System.Drawing.Size(95, 17);
            this.siticoneRadioButton3.TabIndex = 18;
            this.siticoneRadioButton3.TabStop = true;
            this.siticoneRadioButton3.Text = "Normal Mode";
            this.siticoneRadioButton3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton3.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton3.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton3.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton3.UseVisualStyleBackColor = true;
            // 
            // gunaButton3
            // 
            this.gunaButton3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton3.Animated = true;
            this.gunaButton3.AnimationHoverSpeed = 0.07F;
            this.gunaButton3.AnimationSpeed = 0.03F;
            this.gunaButton3.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton3.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.Enabled = false;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton3.ForeColor = System.Drawing.Color.White;
            this.gunaButton3.Image = null;
            this.gunaButton3.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton3.Location = new System.Drawing.Point(468, 516);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton3.Size = new System.Drawing.Size(317, 42);
            this.gunaButton3.TabIndex = 17;
            this.gunaButton3.Text = "Stop Spamming";
            this.gunaButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton3.Click += new System.EventHandler(this.gunaButton3_Click);
            // 
            // gunaButton4
            // 
            this.gunaButton4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton4.Animated = true;
            this.gunaButton4.AnimationHoverSpeed = 0.07F;
            this.gunaButton4.AnimationSpeed = 0.03F;
            this.gunaButton4.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton4.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton4.ForeColor = System.Drawing.Color.White;
            this.gunaButton4.Image = null;
            this.gunaButton4.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton4.Location = new System.Drawing.Point(144, 516);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton4.Size = new System.Drawing.Size(317, 42);
            this.gunaButton4.TabIndex = 16;
            this.gunaButton4.Text = "Start Spamming";
            this.gunaButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton4.Click += new System.EventHandler(this.gunaButton4_Click);
            // 
            // metroLabel18
            // 
            this.metroLabel18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel18.Location = new System.Drawing.Point(723, 352);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(64, 15);
            this.metroLabel18.TabIndex = 13;
            this.metroLabel18.Text = "Delay: 0ms";
            this.metroLabel18.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith2
            // 
            this.siticoneOSToggleSwith2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith2.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith2.Location = new System.Drawing.Point(683, 349);
            this.siticoneOSToggleSwith2.Name = "siticoneOSToggleSwith2";
            this.siticoneOSToggleSwith2.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith2.TabIndex = 12;
            // 
            // siticoneCheckBox9
            // 
            this.siticoneCheckBox9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox9.AutoSize = true;
            this.siticoneCheckBox9.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox9.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox9.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox9.Location = new System.Drawing.Point(144, 395);
            this.siticoneCheckBox9.Name = "siticoneCheckBox9";
            this.siticoneCheckBox9.Size = new System.Drawing.Size(122, 17);
            this.siticoneCheckBox9.TabIndex = 9;
            this.siticoneCheckBox9.Text = "Multiple Messages";
            this.siticoneCheckBox9.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox9.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox9.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox9.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox9.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox8
            // 
            this.siticoneCheckBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox8.AutoSize = true;
            this.siticoneCheckBox8.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox8.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox8.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox8.Location = new System.Drawing.Point(144, 372);
            this.siticoneCheckBox8.Name = "siticoneCheckBox8";
            this.siticoneCheckBox8.Size = new System.Drawing.Size(120, 17);
            this.siticoneCheckBox8.TabIndex = 8;
            this.siticoneCheckBox8.Text = "Multiple Channels";
            this.siticoneCheckBox8.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox8.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox8.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox8.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox8.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox7
            // 
            this.siticoneCheckBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox7.AutoSize = true;
            this.siticoneCheckBox7.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox7.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox7.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox7.Location = new System.Drawing.Point(144, 349);
            this.siticoneCheckBox7.Name = "siticoneCheckBox7";
            this.siticoneCheckBox7.Size = new System.Drawing.Size(99, 17);
            this.siticoneCheckBox7.TabIndex = 7;
            this.siticoneCheckBox7.Text = "Mass Mention";
            this.siticoneCheckBox7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox7.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox7.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox7.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox7.UseVisualStyleBackColor = true;
            // 
            // gunaTextBox1
            // 
            this.gunaTextBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox1.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox1.BorderSize = 1;
            this.gunaTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox1.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox1.FocusedBorderColor = System.Drawing.Color.Red;
            this.gunaTextBox1.FocusedForeColor = System.Drawing.Color.White;
            this.gunaTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox1.Location = new System.Drawing.Point(144, 192);
            this.gunaTextBox1.MaxLength = 2147483647;
            this.gunaTextBox1.MultiLine = true;
            this.gunaTextBox1.Name = "gunaTextBox1";
            this.gunaTextBox1.PasswordChar = '\0';
            this.gunaTextBox1.Size = new System.Drawing.Size(641, 137);
            this.gunaTextBox1.TabIndex = 5;
            this.gunaTextBox1.Text = "Insert the message here.";
            // 
            // gunaLineTextBox5
            // 
            this.gunaLineTextBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox5.Animated = true;
            this.gunaLineTextBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox5.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox5.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox5.LineSize = 1;
            this.gunaLineTextBox5.Location = new System.Drawing.Point(144, 160);
            this.gunaLineTextBox5.MaxLength = 2147483647;
            this.gunaLineTextBox5.Name = "gunaLineTextBox5";
            this.gunaLineTextBox5.PasswordChar = '\0';
            this.gunaLineTextBox5.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox5.TabIndex = 4;
            this.gunaLineTextBox5.Text = "Insert the message reference here (message ID to reply to, not necessary).";
            this.gunaLineTextBox5.TextOffsetX = 0;
            // 
            // gunaLineTextBox4
            // 
            this.gunaLineTextBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox4.Animated = true;
            this.gunaLineTextBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox4.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox4.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox4.LineSize = 1;
            this.gunaLineTextBox4.Location = new System.Drawing.Point(144, 128);
            this.gunaLineTextBox4.MaxLength = 2147483647;
            this.gunaLineTextBox4.Name = "gunaLineTextBox4";
            this.gunaLineTextBox4.PasswordChar = '\0';
            this.gunaLineTextBox4.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox4.TabIndex = 3;
            this.gunaLineTextBox4.Text = "Insert the channel ID here.";
            this.gunaLineTextBox4.TextOffsetX = 0;
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel3.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel3.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(931, 23);
            this.metroLabel3.TabIndex = 1;
            this.metroLabel3.Text = "Server Spammer";
            this.metroLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bunifuHSlider2
            // 
            this.bunifuHSlider2.AllowCursorChanges = true;
            this.bunifuHSlider2.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider2.AllowIncrementalClickMoves = true;
            this.bunifuHSlider2.AllowMouseDownEffects = false;
            this.bunifuHSlider2.AllowMouseHoverEffects = false;
            this.bunifuHSlider2.AllowScrollingAnimations = true;
            this.bunifuHSlider2.AllowScrollKeysDetection = true;
            this.bunifuHSlider2.AllowScrollOptionsMenu = true;
            this.bunifuHSlider2.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider2.BackgroundImage")));
            this.bunifuHSlider2.BindingContainer = null;
            this.bunifuHSlider2.BorderRadius = 2;
            this.bunifuHSlider2.BorderThickness = 1;
            this.bunifuHSlider2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider2.DrawThickBorder = false;
            this.bunifuHSlider2.DurationBeforeShrink = 2000;
            this.bunifuHSlider2.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider2.LargeChange = 10;
            this.bunifuHSlider2.Location = new System.Drawing.Point(144, 454);
            this.bunifuHSlider2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.bunifuHSlider2.Maximum = 5000;
            this.bunifuHSlider2.Minimum = 0;
            this.bunifuHSlider2.MinimumSize = new System.Drawing.Size(0, 54);
            this.bunifuHSlider2.MinimumThumbLength = 18;
            this.bunifuHSlider2.Name = "bunifuHSlider2";
            this.bunifuHSlider2.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider2.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider2.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider2.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider2.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider2.ShrinkSizeLimit = 3;
            this.bunifuHSlider2.Size = new System.Drawing.Size(643, 54);
            this.bunifuHSlider2.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider2.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider2.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider2.SmallChange = 1;
            this.bunifuHSlider2.TabIndex = 15;
            this.bunifuHSlider2.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider2.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider2.ThumbLength = 18;
            this.bunifuHSlider2.ThumbMargin = 1;
            this.bunifuHSlider2.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider2.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider2.Value = 0;
            this.bunifuHSlider2.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider2_Scroll);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage4.Controls.Add(this.siticoneRadioButton6);
            this.tabPage4.Controls.Add(this.siticoneRadioButton7);
            this.tabPage4.Controls.Add(this.siticoneRadioButton8);
            this.tabPage4.Controls.Add(this.metroLabel19);
            this.tabPage4.Controls.Add(this.siticoneOSToggleSwith3);
            this.tabPage4.Controls.Add(this.gunaButton6);
            this.tabPage4.Controls.Add(this.gunaButton5);
            this.tabPage4.Controls.Add(this.siticoneCheckBox12);
            this.tabPage4.Controls.Add(this.siticoneCheckBox11);
            this.tabPage4.Controls.Add(this.gunaTextBox2);
            this.tabPage4.Controls.Add(this.gunaLineTextBox7);
            this.tabPage4.Controls.Add(this.gunaLineTextBox6);
            this.tabPage4.Controls.Add(this.metroLabel4);
            this.tabPage4.Controls.Add(this.bunifuHSlider3);
            this.tabPage4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage4.Location = new System.Drawing.Point(184, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(931, 581);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "DM Spammer";
            // 
            // siticoneRadioButton6
            // 
            this.siticoneRadioButton6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton6.AutoSize = true;
            this.siticoneRadioButton6.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton6.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton6.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton6.Location = new System.Drawing.Point(303, 394);
            this.siticoneRadioButton6.Name = "siticoneRadioButton6";
            this.siticoneRadioButton6.Size = new System.Drawing.Size(103, 17);
            this.siticoneRadioButton6.TabIndex = 23;
            this.siticoneRadioButton6.Text = "Supreme Mode";
            this.siticoneRadioButton6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton6.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton6.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton6.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton6.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton7
            // 
            this.siticoneRadioButton7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton7.AutoSize = true;
            this.siticoneRadioButton7.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton7.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton7.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton7.Location = new System.Drawing.Point(303, 371);
            this.siticoneRadioButton7.Name = "siticoneRadioButton7";
            this.siticoneRadioButton7.Size = new System.Drawing.Size(98, 17);
            this.siticoneRadioButton7.TabIndex = 22;
            this.siticoneRadioButton7.Text = "Extreme Mode";
            this.siticoneRadioButton7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton7.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton7.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton7.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton7.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton8
            // 
            this.siticoneRadioButton8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton8.AutoSize = true;
            this.siticoneRadioButton8.Checked = true;
            this.siticoneRadioButton8.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton8.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton8.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton8.Location = new System.Drawing.Point(303, 349);
            this.siticoneRadioButton8.Name = "siticoneRadioButton8";
            this.siticoneRadioButton8.Size = new System.Drawing.Size(95, 17);
            this.siticoneRadioButton8.TabIndex = 21;
            this.siticoneRadioButton8.TabStop = true;
            this.siticoneRadioButton8.Text = "Normal Mode";
            this.siticoneRadioButton8.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton8.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton8.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton8.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton8.UseVisualStyleBackColor = true;
            // 
            // metroLabel19
            // 
            this.metroLabel19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel19.Location = new System.Drawing.Point(723, 352);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(64, 15);
            this.metroLabel19.TabIndex = 20;
            this.metroLabel19.Text = "Delay: 0ms";
            this.metroLabel19.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith3
            // 
            this.siticoneOSToggleSwith3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith3.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith3.Location = new System.Drawing.Point(683, 349);
            this.siticoneOSToggleSwith3.Name = "siticoneOSToggleSwith3";
            this.siticoneOSToggleSwith3.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith3.TabIndex = 19;
            // 
            // gunaButton6
            // 
            this.gunaButton6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton6.Animated = true;
            this.gunaButton6.AnimationHoverSpeed = 0.07F;
            this.gunaButton6.AnimationSpeed = 0.03F;
            this.gunaButton6.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton6.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton6.Enabled = false;
            this.gunaButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton6.ForeColor = System.Drawing.Color.White;
            this.gunaButton6.Image = null;
            this.gunaButton6.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton6.Location = new System.Drawing.Point(468, 503);
            this.gunaButton6.Name = "gunaButton6";
            this.gunaButton6.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton6.OnHoverImage = null;
            this.gunaButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton6.Size = new System.Drawing.Size(317, 42);
            this.gunaButton6.TabIndex = 18;
            this.gunaButton6.Text = "Stop Spamming";
            this.gunaButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton6.Click += new System.EventHandler(this.gunaButton6_Click);
            // 
            // gunaButton5
            // 
            this.gunaButton5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton5.Animated = true;
            this.gunaButton5.AnimationHoverSpeed = 0.07F;
            this.gunaButton5.AnimationSpeed = 0.03F;
            this.gunaButton5.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton5.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton5.ForeColor = System.Drawing.Color.White;
            this.gunaButton5.Image = null;
            this.gunaButton5.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton5.Location = new System.Drawing.Point(144, 503);
            this.gunaButton5.Name = "gunaButton5";
            this.gunaButton5.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton5.OnHoverImage = null;
            this.gunaButton5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton5.Size = new System.Drawing.Size(317, 42);
            this.gunaButton5.TabIndex = 17;
            this.gunaButton5.Text = "Start Spamming";
            this.gunaButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton5.Click += new System.EventHandler(this.gunaButton5_Click);
            // 
            // siticoneCheckBox12
            // 
            this.siticoneCheckBox12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox12.AutoSize = true;
            this.siticoneCheckBox12.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox12.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox12.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox12.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox12.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox12.Location = new System.Drawing.Point(144, 372);
            this.siticoneCheckBox12.Name = "siticoneCheckBox12";
            this.siticoneCheckBox12.Size = new System.Drawing.Size(122, 17);
            this.siticoneCheckBox12.TabIndex = 9;
            this.siticoneCheckBox12.Text = "Multiple Messages";
            this.siticoneCheckBox12.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox12.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox12.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox12.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox12.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox11
            // 
            this.siticoneCheckBox11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox11.AutoSize = true;
            this.siticoneCheckBox11.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox11.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox11.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox11.Location = new System.Drawing.Point(144, 349);
            this.siticoneCheckBox11.Name = "siticoneCheckBox11";
            this.siticoneCheckBox11.Size = new System.Drawing.Size(100, 17);
            this.siticoneCheckBox11.TabIndex = 8;
            this.siticoneCheckBox11.Text = "Multiple Users";
            this.siticoneCheckBox11.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox11.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox11.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox11.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox11.UseVisualStyleBackColor = true;
            // 
            // gunaTextBox2
            // 
            this.gunaTextBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox2.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox2.BorderSize = 1;
            this.gunaTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox2.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox2.FocusedBorderColor = System.Drawing.Color.Red;
            this.gunaTextBox2.FocusedForeColor = System.Drawing.Color.White;
            this.gunaTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox2.Location = new System.Drawing.Point(144, 192);
            this.gunaTextBox2.MaxLength = 2147483647;
            this.gunaTextBox2.MultiLine = true;
            this.gunaTextBox2.Name = "gunaTextBox2";
            this.gunaTextBox2.PasswordChar = '\0';
            this.gunaTextBox2.Size = new System.Drawing.Size(641, 137);
            this.gunaTextBox2.TabIndex = 6;
            this.gunaTextBox2.Text = "Insert the message here.";
            // 
            // gunaLineTextBox7
            // 
            this.gunaLineTextBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox7.Animated = true;
            this.gunaLineTextBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox7.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox7.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox7.LineSize = 1;
            this.gunaLineTextBox7.Location = new System.Drawing.Point(144, 160);
            this.gunaLineTextBox7.MaxLength = 2147483647;
            this.gunaLineTextBox7.Name = "gunaLineTextBox7";
            this.gunaLineTextBox7.PasswordChar = '\0';
            this.gunaLineTextBox7.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox7.TabIndex = 5;
            this.gunaLineTextBox7.Text = "Insert the message reference here.";
            this.gunaLineTextBox7.TextOffsetX = 0;
            // 
            // gunaLineTextBox6
            // 
            this.gunaLineTextBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox6.Animated = true;
            this.gunaLineTextBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox6.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox6.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox6.LineSize = 1;
            this.gunaLineTextBox6.Location = new System.Drawing.Point(144, 128);
            this.gunaLineTextBox6.MaxLength = 2147483647;
            this.gunaLineTextBox6.Name = "gunaLineTextBox6";
            this.gunaLineTextBox6.PasswordChar = '\0';
            this.gunaLineTextBox6.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox6.TabIndex = 4;
            this.gunaLineTextBox6.Text = "Insert the user ID here.";
            this.gunaLineTextBox6.TextOffsetX = 0;
            // 
            // metroLabel4
            // 
            this.metroLabel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel4.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel4.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(931, 23);
            this.metroLabel4.TabIndex = 1;
            this.metroLabel4.Text = "DM Spammer";
            this.metroLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bunifuHSlider3
            // 
            this.bunifuHSlider3.AllowCursorChanges = true;
            this.bunifuHSlider3.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider3.AllowIncrementalClickMoves = true;
            this.bunifuHSlider3.AllowMouseDownEffects = false;
            this.bunifuHSlider3.AllowMouseHoverEffects = false;
            this.bunifuHSlider3.AllowScrollingAnimations = true;
            this.bunifuHSlider3.AllowScrollKeysDetection = true;
            this.bunifuHSlider3.AllowScrollOptionsMenu = true;
            this.bunifuHSlider3.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider3.BackgroundImage")));
            this.bunifuHSlider3.BindingContainer = null;
            this.bunifuHSlider3.BorderRadius = 2;
            this.bunifuHSlider3.BorderThickness = 1;
            this.bunifuHSlider3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider3.DrawThickBorder = false;
            this.bunifuHSlider3.DurationBeforeShrink = 2000;
            this.bunifuHSlider3.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider3.LargeChange = 10;
            this.bunifuHSlider3.Location = new System.Drawing.Point(144, 422);
            this.bunifuHSlider3.Margin = new System.Windows.Forms.Padding(3, 7, 3, 7);
            this.bunifuHSlider3.Maximum = 5000;
            this.bunifuHSlider3.Minimum = 0;
            this.bunifuHSlider3.MinimumSize = new System.Drawing.Size(0, 71);
            this.bunifuHSlider3.MinimumThumbLength = 18;
            this.bunifuHSlider3.Name = "bunifuHSlider3";
            this.bunifuHSlider3.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider3.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider3.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider3.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider3.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider3.ShrinkSizeLimit = 3;
            this.bunifuHSlider3.Size = new System.Drawing.Size(641, 71);
            this.bunifuHSlider3.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider3.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider3.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider3.SmallChange = 1;
            this.bunifuHSlider3.TabIndex = 16;
            this.bunifuHSlider3.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider3.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider3.ThumbLength = 18;
            this.bunifuHSlider3.ThumbMargin = 1;
            this.bunifuHSlider3.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider3.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider3.Value = 0;
            this.bunifuHSlider3.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider3_Scroll);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage5.Controls.Add(this.siticoneButton7);
            this.tabPage5.Controls.Add(this.gunaButton8);
            this.tabPage5.Controls.Add(this.gunaButton7);
            this.tabPage5.Controls.Add(this.metroLabel20);
            this.tabPage5.Controls.Add(this.siticoneOSToggleSwith4);
            this.tabPage5.Controls.Add(this.siticoneRadioButton2);
            this.tabPage5.Controls.Add(this.siticoneRadioButton1);
            this.tabPage5.Controls.Add(this.gunaLineTextBox10);
            this.tabPage5.Controls.Add(this.gunaLineTextBox9);
            this.tabPage5.Controls.Add(this.gunaLineTextBox8);
            this.tabPage5.Controls.Add(this.metroLabel5);
            this.tabPage5.Controls.Add(this.bunifuHSlider4);
            this.tabPage5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage5.Location = new System.Drawing.Point(184, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(931, 581);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Reaction Spammer";
            // 
            // siticoneButton7
            // 
            this.siticoneButton7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton7.BorderRadius = 15;
            this.siticoneButton7.CheckedState.Parent = this.siticoneButton7;
            this.siticoneButton7.CustomImages.Parent = this.siticoneButton7;
            this.siticoneButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton7.ForeColor = System.Drawing.Color.White;
            this.siticoneButton7.HoveredState.Parent = this.siticoneButton7;
            this.siticoneButton7.Location = new System.Drawing.Point(584, 119);
            this.siticoneButton7.Name = "siticoneButton7";
            this.siticoneButton7.ShadowDecoration.Parent = this.siticoneButton7;
            this.siticoneButton7.Size = new System.Drawing.Size(204, 45);
            this.siticoneButton7.TabIndex = 26;
            this.siticoneButton7.Text = "Fetch from message";
            this.siticoneButton7.Click += new System.EventHandler(this.siticoneButton7_Click);
            // 
            // gunaButton8
            // 
            this.gunaButton8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton8.Animated = true;
            this.gunaButton8.AnimationHoverSpeed = 0.07F;
            this.gunaButton8.AnimationSpeed = 0.03F;
            this.gunaButton8.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton8.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton8.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton8.ForeColor = System.Drawing.Color.White;
            this.gunaButton8.Image = null;
            this.gunaButton8.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton8.Location = new System.Drawing.Point(468, 392);
            this.gunaButton8.Name = "gunaButton8";
            this.gunaButton8.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton8.OnHoverImage = null;
            this.gunaButton8.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton8.Size = new System.Drawing.Size(317, 42);
            this.gunaButton8.TabIndex = 25;
            this.gunaButton8.Text = "Remove reaction";
            this.gunaButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton8.Click += new System.EventHandler(this.gunaButton8_Click);
            // 
            // gunaButton7
            // 
            this.gunaButton7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton7.Animated = true;
            this.gunaButton7.AnimationHoverSpeed = 0.07F;
            this.gunaButton7.AnimationSpeed = 0.03F;
            this.gunaButton7.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton7.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton7.ForeColor = System.Drawing.Color.White;
            this.gunaButton7.Image = null;
            this.gunaButton7.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton7.Location = new System.Drawing.Point(144, 392);
            this.gunaButton7.Name = "gunaButton7";
            this.gunaButton7.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton7.OnHoverImage = null;
            this.gunaButton7.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton7.Size = new System.Drawing.Size(317, 42);
            this.gunaButton7.TabIndex = 24;
            this.gunaButton7.Text = "Add reaction";
            this.gunaButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton7.Click += new System.EventHandler(this.gunaButton7_Click);
            // 
            // metroLabel20
            // 
            this.metroLabel20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel20.Location = new System.Drawing.Point(724, 238);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(64, 15);
            this.metroLabel20.TabIndex = 22;
            this.metroLabel20.Text = "Delay: 0ms";
            this.metroLabel20.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith4
            // 
            this.siticoneOSToggleSwith4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith4.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith4.Location = new System.Drawing.Point(684, 235);
            this.siticoneOSToggleSwith4.Name = "siticoneOSToggleSwith4";
            this.siticoneOSToggleSwith4.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith4.TabIndex = 21;
            // 
            // siticoneRadioButton2
            // 
            this.siticoneRadioButton2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton2.AutoSize = true;
            this.siticoneRadioButton2.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton2.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton2.Location = new System.Drawing.Point(144, 258);
            this.siticoneRadioButton2.Name = "siticoneRadioButton2";
            this.siticoneRadioButton2.Size = new System.Drawing.Size(90, 17);
            this.siticoneRadioButton2.TabIndex = 9;
            this.siticoneRadioButton2.Text = "Emote Mode";
            this.siticoneRadioButton2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton2.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton2.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton2.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton2.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton1
            // 
            this.siticoneRadioButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton1.AutoSize = true;
            this.siticoneRadioButton1.Checked = true;
            this.siticoneRadioButton1.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton1.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton1.Location = new System.Drawing.Point(144, 235);
            this.siticoneRadioButton1.Name = "siticoneRadioButton1";
            this.siticoneRadioButton1.Size = new System.Drawing.Size(86, 17);
            this.siticoneRadioButton1.TabIndex = 8;
            this.siticoneRadioButton1.TabStop = true;
            this.siticoneRadioButton1.Text = "Emoji Mode";
            this.siticoneRadioButton1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton1.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton1.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton1.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton1.UseVisualStyleBackColor = true;
            // 
            // gunaLineTextBox10
            // 
            this.gunaLineTextBox10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox10.Animated = true;
            this.gunaLineTextBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox10.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox10.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox10.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox10.LineSize = 1;
            this.gunaLineTextBox10.Location = new System.Drawing.Point(144, 192);
            this.gunaLineTextBox10.MaxLength = 2147483647;
            this.gunaLineTextBox10.Name = "gunaLineTextBox10";
            this.gunaLineTextBox10.PasswordChar = '\0';
            this.gunaLineTextBox10.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox10.TabIndex = 7;
            this.gunaLineTextBox10.Text = "Insert the message ID here.";
            this.gunaLineTextBox10.TextOffsetX = 0;
            // 
            // gunaLineTextBox9
            // 
            this.gunaLineTextBox9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox9.Animated = true;
            this.gunaLineTextBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox9.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox9.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox9.LineSize = 1;
            this.gunaLineTextBox9.Location = new System.Drawing.Point(144, 160);
            this.gunaLineTextBox9.MaxLength = 2147483647;
            this.gunaLineTextBox9.Name = "gunaLineTextBox9";
            this.gunaLineTextBox9.PasswordChar = '\0';
            this.gunaLineTextBox9.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox9.TabIndex = 6;
            this.gunaLineTextBox9.Text = "Insert the channel ID here.";
            this.gunaLineTextBox9.TextOffsetX = 0;
            // 
            // gunaLineTextBox8
            // 
            this.gunaLineTextBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox8.Animated = true;
            this.gunaLineTextBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox8.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox8.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox8.LineSize = 1;
            this.gunaLineTextBox8.Location = new System.Drawing.Point(144, 128);
            this.gunaLineTextBox8.MaxLength = 2147483647;
            this.gunaLineTextBox8.Name = "gunaLineTextBox8";
            this.gunaLineTextBox8.PasswordChar = '\0';
            this.gunaLineTextBox8.Size = new System.Drawing.Size(434, 26);
            this.gunaLineTextBox8.TabIndex = 5;
            this.gunaLineTextBox8.Text = "Insert the emoji or the <emote_name:emote_id> here.";
            this.gunaLineTextBox8.TextOffsetX = 0;
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel5.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel5.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(931, 23);
            this.metroLabel5.TabIndex = 1;
            this.metroLabel5.Text = "Reaction Spammer";
            this.metroLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bunifuHSlider4
            // 
            this.bunifuHSlider4.AllowCursorChanges = true;
            this.bunifuHSlider4.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider4.AllowIncrementalClickMoves = true;
            this.bunifuHSlider4.AllowMouseDownEffects = false;
            this.bunifuHSlider4.AllowMouseHoverEffects = false;
            this.bunifuHSlider4.AllowScrollingAnimations = true;
            this.bunifuHSlider4.AllowScrollKeysDetection = true;
            this.bunifuHSlider4.AllowScrollOptionsMenu = true;
            this.bunifuHSlider4.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider4.BackgroundImage")));
            this.bunifuHSlider4.BindingContainer = null;
            this.bunifuHSlider4.BorderRadius = 2;
            this.bunifuHSlider4.BorderThickness = 1;
            this.bunifuHSlider4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider4.DrawThickBorder = false;
            this.bunifuHSlider4.DurationBeforeShrink = 2000;
            this.bunifuHSlider4.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider4.LargeChange = 10;
            this.bunifuHSlider4.Location = new System.Drawing.Point(144, 287);
            this.bunifuHSlider4.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.bunifuHSlider4.Maximum = 5000;
            this.bunifuHSlider4.Minimum = 0;
            this.bunifuHSlider4.MinimumSize = new System.Drawing.Size(0, 93);
            this.bunifuHSlider4.MinimumThumbLength = 18;
            this.bunifuHSlider4.Name = "bunifuHSlider4";
            this.bunifuHSlider4.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider4.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider4.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider4.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider4.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider4.ShrinkSizeLimit = 3;
            this.bunifuHSlider4.Size = new System.Drawing.Size(644, 93);
            this.bunifuHSlider4.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider4.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider4.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider4.SmallChange = 1;
            this.bunifuHSlider4.TabIndex = 23;
            this.bunifuHSlider4.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider4.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider4.ThumbLength = 18;
            this.bunifuHSlider4.ThumbMargin = 1;
            this.bunifuHSlider4.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider4.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider4.Value = 0;
            this.bunifuHSlider4.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider4_Scroll);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage6.Controls.Add(this.siticoneCheckBox35);
            this.tabPage6.Controls.Add(this.bunifuHSlider5);
            this.tabPage6.Controls.Add(this.gunaButton9);
            this.tabPage6.Controls.Add(this.gunaButton10);
            this.tabPage6.Controls.Add(this.metroLabel21);
            this.tabPage6.Controls.Add(this.siticoneOSToggleSwith5);
            this.tabPage6.Controls.Add(this.siticoneCheckBox5);
            this.tabPage6.Controls.Add(this.gunaLineTextBox11);
            this.tabPage6.Controls.Add(this.metroLabel6);
            this.tabPage6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage6.Location = new System.Drawing.Point(184, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(931, 581);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Friend Spammer";
            // 
            // siticoneCheckBox35
            // 
            this.siticoneCheckBox35.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox35.AutoSize = true;
            this.siticoneCheckBox35.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox35.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox35.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox35.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox35.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox35.Location = new System.Drawing.Point(144, 196);
            this.siticoneCheckBox35.Name = "siticoneCheckBox35";
            this.siticoneCheckBox35.Size = new System.Drawing.Size(87, 17);
            this.siticoneCheckBox35.TabIndex = 29;
            this.siticoneCheckBox35.Text = "Spam Mode";
            this.siticoneCheckBox35.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox35.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox35.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox35.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox35.UseVisualStyleBackColor = true;
            this.siticoneCheckBox35.CheckedChanged += new System.EventHandler(this.siticoneCheckBox35_CheckedChanged);
            // 
            // bunifuHSlider5
            // 
            this.bunifuHSlider5.AllowCursorChanges = true;
            this.bunifuHSlider5.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider5.AllowIncrementalClickMoves = true;
            this.bunifuHSlider5.AllowMouseDownEffects = false;
            this.bunifuHSlider5.AllowMouseHoverEffects = false;
            this.bunifuHSlider5.AllowScrollingAnimations = true;
            this.bunifuHSlider5.AllowScrollKeysDetection = true;
            this.bunifuHSlider5.AllowScrollOptionsMenu = true;
            this.bunifuHSlider5.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider5.BackgroundImage")));
            this.bunifuHSlider5.BindingContainer = null;
            this.bunifuHSlider5.BorderRadius = 2;
            this.bunifuHSlider5.BorderThickness = 1;
            this.bunifuHSlider5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider5.DrawThickBorder = false;
            this.bunifuHSlider5.DurationBeforeShrink = 2000;
            this.bunifuHSlider5.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider5.LargeChange = 10;
            this.bunifuHSlider5.Location = new System.Drawing.Point(144, 226);
            this.bunifuHSlider5.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.bunifuHSlider5.Maximum = 5000;
            this.bunifuHSlider5.Minimum = 0;
            this.bunifuHSlider5.MinimumSize = new System.Drawing.Size(0, 54);
            this.bunifuHSlider5.MinimumThumbLength = 18;
            this.bunifuHSlider5.Name = "bunifuHSlider5";
            this.bunifuHSlider5.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider5.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider5.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider5.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider5.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider5.ShrinkSizeLimit = 3;
            this.bunifuHSlider5.Size = new System.Drawing.Size(644, 54);
            this.bunifuHSlider5.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider5.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider5.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider5.SmallChange = 1;
            this.bunifuHSlider5.TabIndex = 28;
            this.bunifuHSlider5.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider5.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider5.ThumbLength = 18;
            this.bunifuHSlider5.ThumbMargin = 1;
            this.bunifuHSlider5.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider5.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider5.Value = 0;
            this.bunifuHSlider5.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider5_Scroll);
            // 
            // gunaButton9
            // 
            this.gunaButton9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton9.Animated = true;
            this.gunaButton9.AnimationHoverSpeed = 0.07F;
            this.gunaButton9.AnimationSpeed = 0.03F;
            this.gunaButton9.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton9.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton9.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton9.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton9.ForeColor = System.Drawing.Color.White;
            this.gunaButton9.Image = null;
            this.gunaButton9.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton9.Location = new System.Drawing.Point(471, 300);
            this.gunaButton9.Name = "gunaButton9";
            this.gunaButton9.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton9.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton9.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton9.OnHoverImage = null;
            this.gunaButton9.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton9.Size = new System.Drawing.Size(317, 42);
            this.gunaButton9.TabIndex = 27;
            this.gunaButton9.Text = "Remove friend";
            this.gunaButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton9.Click += new System.EventHandler(this.gunaButton9_Click);
            // 
            // gunaButton10
            // 
            this.gunaButton10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton10.Animated = true;
            this.gunaButton10.AnimationHoverSpeed = 0.07F;
            this.gunaButton10.AnimationSpeed = 0.03F;
            this.gunaButton10.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton10.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton10.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton10.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton10.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton10.ForeColor = System.Drawing.Color.White;
            this.gunaButton10.Image = null;
            this.gunaButton10.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton10.Location = new System.Drawing.Point(144, 300);
            this.gunaButton10.Name = "gunaButton10";
            this.gunaButton10.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton10.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton10.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton10.OnHoverImage = null;
            this.gunaButton10.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton10.Size = new System.Drawing.Size(317, 42);
            this.gunaButton10.TabIndex = 26;
            this.gunaButton10.Text = "Add friend";
            this.gunaButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton10.Click += new System.EventHandler(this.gunaButton10_Click);
            // 
            // metroLabel21
            // 
            this.metroLabel21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel21.Location = new System.Drawing.Point(724, 176);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(64, 15);
            this.metroLabel21.TabIndex = 24;
            this.metroLabel21.Text = "Delay: 0ms";
            this.metroLabel21.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith5
            // 
            this.siticoneOSToggleSwith5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith5.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith5.Location = new System.Drawing.Point(684, 173);
            this.siticoneOSToggleSwith5.Name = "siticoneOSToggleSwith5";
            this.siticoneOSToggleSwith5.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith5.TabIndex = 23;
            // 
            // siticoneCheckBox5
            // 
            this.siticoneCheckBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox5.AutoSize = true;
            this.siticoneCheckBox5.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox5.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox5.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox5.Location = new System.Drawing.Point(144, 173);
            this.siticoneCheckBox5.Name = "siticoneCheckBox5";
            this.siticoneCheckBox5.Size = new System.Drawing.Size(110, 17);
            this.siticoneCheckBox5.TabIndex = 7;
            this.siticoneCheckBox5.Text = "Multiple Friends";
            this.siticoneCheckBox5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox5.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox5.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox5.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox5.UseVisualStyleBackColor = true;
            // 
            // gunaLineTextBox11
            // 
            this.gunaLineTextBox11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox11.Animated = true;
            this.gunaLineTextBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox11.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox11.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox11.LineSize = 1;
            this.gunaLineTextBox11.Location = new System.Drawing.Point(144, 128);
            this.gunaLineTextBox11.MaxLength = 2147483647;
            this.gunaLineTextBox11.Name = "gunaLineTextBox11";
            this.gunaLineTextBox11.PasswordChar = '\0';
            this.gunaLineTextBox11.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox11.TabIndex = 4;
            this.gunaLineTextBox11.Text = "Insert the username#tag or friend ID here.";
            this.gunaLineTextBox11.TextOffsetX = 0;
            // 
            // metroLabel6
            // 
            this.metroLabel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel6.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel6.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(931, 23);
            this.metroLabel6.TabIndex = 1;
            this.metroLabel6.Text = "Friend Spammer";
            this.metroLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage7.Controls.Add(this.bunifuHSlider6);
            this.tabPage7.Controls.Add(this.gunaButton12);
            this.tabPage7.Controls.Add(this.gunaButton11);
            this.tabPage7.Controls.Add(this.metroLabel22);
            this.tabPage7.Controls.Add(this.siticoneOSToggleSwith6);
            this.tabPage7.Controls.Add(this.siticoneCheckBox13);
            this.tabPage7.Controls.Add(this.gunaLineTextBox12);
            this.tabPage7.Controls.Add(this.metroLabel7);
            this.tabPage7.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage7.Location = new System.Drawing.Point(184, 4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(931, 581);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Typing Spammer";
            // 
            // bunifuHSlider6
            // 
            this.bunifuHSlider6.AllowCursorChanges = true;
            this.bunifuHSlider6.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider6.AllowIncrementalClickMoves = true;
            this.bunifuHSlider6.AllowMouseDownEffects = false;
            this.bunifuHSlider6.AllowMouseHoverEffects = false;
            this.bunifuHSlider6.AllowScrollingAnimations = true;
            this.bunifuHSlider6.AllowScrollKeysDetection = true;
            this.bunifuHSlider6.AllowScrollOptionsMenu = true;
            this.bunifuHSlider6.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider6.BackgroundImage")));
            this.bunifuHSlider6.BindingContainer = null;
            this.bunifuHSlider6.BorderRadius = 2;
            this.bunifuHSlider6.BorderThickness = 1;
            this.bunifuHSlider6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider6.DrawThickBorder = false;
            this.bunifuHSlider6.DurationBeforeShrink = 2000;
            this.bunifuHSlider6.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider6.LargeChange = 10;
            this.bunifuHSlider6.Location = new System.Drawing.Point(144, 226);
            this.bunifuHSlider6.Margin = new System.Windows.Forms.Padding(3, 7, 3, 7);
            this.bunifuHSlider6.Maximum = 5000;
            this.bunifuHSlider6.Minimum = 0;
            this.bunifuHSlider6.MinimumSize = new System.Drawing.Size(0, 71);
            this.bunifuHSlider6.MinimumThumbLength = 18;
            this.bunifuHSlider6.Name = "bunifuHSlider6";
            this.bunifuHSlider6.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider6.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider6.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider6.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider6.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider6.ShrinkSizeLimit = 3;
            this.bunifuHSlider6.Size = new System.Drawing.Size(644, 71);
            this.bunifuHSlider6.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider6.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider6.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider6.SmallChange = 1;
            this.bunifuHSlider6.TabIndex = 32;
            this.bunifuHSlider6.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider6.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider6.ThumbLength = 18;
            this.bunifuHSlider6.ThumbMargin = 1;
            this.bunifuHSlider6.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider6.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider6.Value = 0;
            this.bunifuHSlider6.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider6_Scroll);
            // 
            // gunaButton12
            // 
            this.gunaButton12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton12.Animated = true;
            this.gunaButton12.AnimationHoverSpeed = 0.07F;
            this.gunaButton12.AnimationSpeed = 0.03F;
            this.gunaButton12.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton12.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton12.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton12.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton12.Enabled = false;
            this.gunaButton12.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton12.ForeColor = System.Drawing.Color.White;
            this.gunaButton12.Image = null;
            this.gunaButton12.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton12.Location = new System.Drawing.Point(471, 300);
            this.gunaButton12.Name = "gunaButton12";
            this.gunaButton12.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton12.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton12.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton12.OnHoverImage = null;
            this.gunaButton12.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton12.Size = new System.Drawing.Size(317, 42);
            this.gunaButton12.TabIndex = 31;
            this.gunaButton12.Text = "Stop Spamming";
            this.gunaButton12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton12.Click += new System.EventHandler(this.gunaButton12_Click);
            // 
            // gunaButton11
            // 
            this.gunaButton11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton11.Animated = true;
            this.gunaButton11.AnimationHoverSpeed = 0.07F;
            this.gunaButton11.AnimationSpeed = 0.03F;
            this.gunaButton11.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton11.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton11.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton11.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton11.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton11.ForeColor = System.Drawing.Color.White;
            this.gunaButton11.Image = null;
            this.gunaButton11.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton11.Location = new System.Drawing.Point(144, 300);
            this.gunaButton11.Name = "gunaButton11";
            this.gunaButton11.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton11.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton11.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton11.OnHoverImage = null;
            this.gunaButton11.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton11.Size = new System.Drawing.Size(317, 42);
            this.gunaButton11.TabIndex = 30;
            this.gunaButton11.Text = "Start Spamming";
            this.gunaButton11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton11.Click += new System.EventHandler(this.gunaButton11_Click);
            // 
            // metroLabel22
            // 
            this.metroLabel22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel22.Location = new System.Drawing.Point(724, 176);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(64, 15);
            this.metroLabel22.TabIndex = 26;
            this.metroLabel22.Text = "Delay: 0ms";
            this.metroLabel22.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith6
            // 
            this.siticoneOSToggleSwith6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith6.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith6.Location = new System.Drawing.Point(684, 173);
            this.siticoneOSToggleSwith6.Name = "siticoneOSToggleSwith6";
            this.siticoneOSToggleSwith6.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith6.TabIndex = 25;
            // 
            // siticoneCheckBox13
            // 
            this.siticoneCheckBox13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox13.AutoSize = true;
            this.siticoneCheckBox13.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox13.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox13.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox13.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox13.Location = new System.Drawing.Point(144, 173);
            this.siticoneCheckBox13.Name = "siticoneCheckBox13";
            this.siticoneCheckBox13.Size = new System.Drawing.Size(120, 17);
            this.siticoneCheckBox13.TabIndex = 8;
            this.siticoneCheckBox13.Text = "Multiple Channels";
            this.siticoneCheckBox13.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox13.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox13.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox13.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox13.UseVisualStyleBackColor = true;
            // 
            // gunaLineTextBox12
            // 
            this.gunaLineTextBox12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox12.Animated = true;
            this.gunaLineTextBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox12.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox12.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox12.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox12.LineSize = 1;
            this.gunaLineTextBox12.Location = new System.Drawing.Point(144, 128);
            this.gunaLineTextBox12.MaxLength = 2147483647;
            this.gunaLineTextBox12.Name = "gunaLineTextBox12";
            this.gunaLineTextBox12.PasswordChar = '\0';
            this.gunaLineTextBox12.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox12.TabIndex = 5;
            this.gunaLineTextBox12.Text = "Insert the channel ID here.";
            this.gunaLineTextBox12.TextOffsetX = 0;
            // 
            // metroLabel7
            // 
            this.metroLabel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel7.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel7.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(931, 23);
            this.metroLabel7.TabIndex = 1;
            this.metroLabel7.Text = "Typing Spammer";
            this.metroLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage9.Controls.Add(this.gunaLineTextBox16);
            this.tabPage9.Controls.Add(this.gunaButton16);
            this.tabPage9.Controls.Add(this.gunaButton15);
            this.tabPage9.Controls.Add(this.siticoneCheckBox21);
            this.tabPage9.Controls.Add(this.siticoneCheckBox20);
            this.tabPage9.Controls.Add(this.siticoneCheckBox19);
            this.tabPage9.Controls.Add(this.siticoneCheckBox18);
            this.tabPage9.Controls.Add(this.siticoneCheckBox17);
            this.tabPage9.Controls.Add(this.siticoneCheckBox16);
            this.tabPage9.Controls.Add(this.siticoneCheckBox15);
            this.tabPage9.Controls.Add(this.siticoneCheckBox14);
            this.tabPage9.Controls.Add(this.metroLabel26);
            this.tabPage9.Controls.Add(this.siticoneOSToggleSwith10);
            this.tabPage9.Controls.Add(this.metroLabel25);
            this.tabPage9.Controls.Add(this.siticoneOSToggleSwith9);
            this.tabPage9.Controls.Add(this.gunaLineTextBox15);
            this.tabPage9.Controls.Add(this.gunaLineTextBox14);
            this.tabPage9.Controls.Add(this.metroLabel9);
            this.tabPage9.Controls.Add(this.bunifuHSlider10);
            this.tabPage9.Controls.Add(this.bunifuHSlider9);
            this.tabPage9.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage9.Location = new System.Drawing.Point(184, 4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(931, 581);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Voice Spammer";
            // 
            // gunaLineTextBox16
            // 
            this.gunaLineTextBox16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox16.Animated = true;
            this.gunaLineTextBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox16.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox16.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox16.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox16.LineSize = 1;
            this.gunaLineTextBox16.Location = new System.Drawing.Point(144, 192);
            this.gunaLineTextBox16.MaxLength = 2147483647;
            this.gunaLineTextBox16.Name = "gunaLineTextBox16";
            this.gunaLineTextBox16.PasswordChar = '\0';
            this.gunaLineTextBox16.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox16.TabIndex = 46;
            this.gunaLineTextBox16.Text = "Insert the user ID where to join go live.";
            this.gunaLineTextBox16.TextOffsetX = 0;
            // 
            // gunaButton16
            // 
            this.gunaButton16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton16.Animated = true;
            this.gunaButton16.AnimationHoverSpeed = 0.07F;
            this.gunaButton16.AnimationSpeed = 0.03F;
            this.gunaButton16.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton16.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton16.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton16.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton16.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton16.ForeColor = System.Drawing.Color.White;
            this.gunaButton16.Image = null;
            this.gunaButton16.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton16.Location = new System.Drawing.Point(468, 522);
            this.gunaButton16.Name = "gunaButton16";
            this.gunaButton16.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton16.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton16.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton16.OnHoverImage = null;
            this.gunaButton16.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton16.Size = new System.Drawing.Size(317, 42);
            this.gunaButton16.TabIndex = 45;
            this.gunaButton16.Text = "Leave voice";
            this.gunaButton16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton16.Click += new System.EventHandler(this.gunaButton16_Click);
            // 
            // gunaButton15
            // 
            this.gunaButton15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton15.Animated = true;
            this.gunaButton15.AnimationHoverSpeed = 0.07F;
            this.gunaButton15.AnimationSpeed = 0.03F;
            this.gunaButton15.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton15.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton15.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton15.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton15.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton15.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton15.ForeColor = System.Drawing.Color.White;
            this.gunaButton15.Image = null;
            this.gunaButton15.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton15.Location = new System.Drawing.Point(144, 522);
            this.gunaButton15.Name = "gunaButton15";
            this.gunaButton15.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton15.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton15.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton15.OnHoverImage = null;
            this.gunaButton15.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton15.Size = new System.Drawing.Size(317, 42);
            this.gunaButton15.TabIndex = 44;
            this.gunaButton15.Text = "Join voice";
            this.gunaButton15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton15.Click += new System.EventHandler(this.gunaButton15_Click);
            // 
            // siticoneCheckBox21
            // 
            this.siticoneCheckBox21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox21.AutoSize = true;
            this.siticoneCheckBox21.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox21.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox21.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox21.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox21.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox21.Location = new System.Drawing.Point(275, 491);
            this.siticoneCheckBox21.Name = "siticoneCheckBox21";
            this.siticoneCheckBox21.Size = new System.Drawing.Size(82, 17);
            this.siticoneCheckBox21.TabIndex = 43;
            this.siticoneCheckBox21.Text = "Auto Leave";
            this.siticoneCheckBox21.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox21.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox21.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox21.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox21.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox20
            // 
            this.siticoneCheckBox20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox20.AutoSize = true;
            this.siticoneCheckBox20.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox20.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox20.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox20.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox20.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox20.Location = new System.Drawing.Point(275, 468);
            this.siticoneCheckBox20.Name = "siticoneCheckBox20";
            this.siticoneCheckBox20.Size = new System.Drawing.Size(129, 17);
            this.siticoneCheckBox20.TabIndex = 42;
            this.siticoneCheckBox20.Text = "Send speak in stage";
            this.siticoneCheckBox20.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox20.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox20.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox20.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox20.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox19
            // 
            this.siticoneCheckBox19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox19.AutoSize = true;
            this.siticoneCheckBox19.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox19.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox19.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox19.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox19.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox19.Location = new System.Drawing.Point(275, 445);
            this.siticoneCheckBox19.Name = "siticoneCheckBox19";
            this.siticoneCheckBox19.Size = new System.Drawing.Size(108, 17);
            this.siticoneCheckBox19.TabIndex = 41;
            this.siticoneCheckBox19.Text = "Auto Reconnect";
            this.siticoneCheckBox19.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox19.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox19.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox19.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox19.UseVisualStyleBackColor = true;
            this.siticoneCheckBox19.CheckedChanged += new System.EventHandler(this.siticoneCheckBox19_CheckedChanged);
            // 
            // siticoneCheckBox18
            // 
            this.siticoneCheckBox18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox18.AutoSize = true;
            this.siticoneCheckBox18.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox18.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox18.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox18.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox18.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox18.Location = new System.Drawing.Point(275, 422);
            this.siticoneCheckBox18.Name = "siticoneCheckBox18";
            this.siticoneCheckBox18.Size = new System.Drawing.Size(87, 17);
            this.siticoneCheckBox18.TabIndex = 40;
            this.siticoneCheckBox18.Text = "Join Go Live";
            this.siticoneCheckBox18.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox18.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox18.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox18.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox18.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox17
            // 
            this.siticoneCheckBox17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox17.AutoSize = true;
            this.siticoneCheckBox17.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox17.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox17.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox17.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox17.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox17.Location = new System.Drawing.Point(144, 491);
            this.siticoneCheckBox17.Name = "siticoneCheckBox17";
            this.siticoneCheckBox17.Size = new System.Drawing.Size(63, 17);
            this.siticoneCheckBox17.TabIndex = 39;
            this.siticoneCheckBox17.Text = "Go Live";
            this.siticoneCheckBox17.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox17.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox17.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox17.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox17.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox16
            // 
            this.siticoneCheckBox16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox16.AutoSize = true;
            this.siticoneCheckBox16.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox16.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox16.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox16.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox16.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox16.Location = new System.Drawing.Point(144, 468);
            this.siticoneCheckBox16.Name = "siticoneCheckBox16";
            this.siticoneCheckBox16.Size = new System.Drawing.Size(101, 17);
            this.siticoneCheckBox16.TabIndex = 38;
            this.siticoneCheckBox16.Text = "Video enabled";
            this.siticoneCheckBox16.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox16.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox16.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox16.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox16.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox15
            // 
            this.siticoneCheckBox15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox15.AutoSize = true;
            this.siticoneCheckBox15.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox15.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox15.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox15.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox15.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox15.Location = new System.Drawing.Point(144, 445);
            this.siticoneCheckBox15.Name = "siticoneCheckBox15";
            this.siticoneCheckBox15.Size = new System.Drawing.Size(128, 17);
            this.siticoneCheckBox15.TabIndex = 37;
            this.siticoneCheckBox15.Text = "Headphones muted";
            this.siticoneCheckBox15.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox15.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox15.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox15.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox15.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox14
            // 
            this.siticoneCheckBox14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox14.AutoSize = true;
            this.siticoneCheckBox14.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox14.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox14.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox14.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox14.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox14.Location = new System.Drawing.Point(144, 422);
            this.siticoneCheckBox14.Name = "siticoneCheckBox14";
            this.siticoneCheckBox14.Size = new System.Drawing.Size(125, 17);
            this.siticoneCheckBox14.TabIndex = 36;
            this.siticoneCheckBox14.Text = "Microphone muted";
            this.siticoneCheckBox14.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox14.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox14.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox14.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox14.UseVisualStyleBackColor = true;
            // 
            // metroLabel26
            // 
            this.metroLabel26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel26.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel26.Location = new System.Drawing.Point(721, 322);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(91, 15);
            this.metroLabel26.TabIndex = 33;
            this.metroLabel26.Text = "Auto leave: 0ms";
            this.metroLabel26.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith10
            // 
            this.siticoneOSToggleSwith10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith10.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith10.Location = new System.Drawing.Point(681, 319);
            this.siticoneOSToggleSwith10.Name = "siticoneOSToggleSwith10";
            this.siticoneOSToggleSwith10.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith10.TabIndex = 32;
            // 
            // metroLabel25
            // 
            this.metroLabel25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel25.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel25.Location = new System.Drawing.Point(721, 234);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(64, 15);
            this.metroLabel25.TabIndex = 30;
            this.metroLabel25.Text = "Delay: 0ms";
            this.metroLabel25.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith9
            // 
            this.siticoneOSToggleSwith9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith9.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith9.Location = new System.Drawing.Point(681, 231);
            this.siticoneOSToggleSwith9.Name = "siticoneOSToggleSwith9";
            this.siticoneOSToggleSwith9.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith9.TabIndex = 29;
            // 
            // gunaLineTextBox15
            // 
            this.gunaLineTextBox15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox15.Animated = true;
            this.gunaLineTextBox15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox15.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox15.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox15.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox15.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox15.LineSize = 1;
            this.gunaLineTextBox15.Location = new System.Drawing.Point(144, 160);
            this.gunaLineTextBox15.MaxLength = 2147483647;
            this.gunaLineTextBox15.Name = "gunaLineTextBox15";
            this.gunaLineTextBox15.PasswordChar = '\0';
            this.gunaLineTextBox15.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox15.TabIndex = 7;
            this.gunaLineTextBox15.Text = "Insert the channel ID here.";
            this.gunaLineTextBox15.TextOffsetX = 0;
            // 
            // gunaLineTextBox14
            // 
            this.gunaLineTextBox14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox14.Animated = true;
            this.gunaLineTextBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox14.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox14.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox14.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox14.LineSize = 1;
            this.gunaLineTextBox14.Location = new System.Drawing.Point(144, 128);
            this.gunaLineTextBox14.MaxLength = 2147483647;
            this.gunaLineTextBox14.Name = "gunaLineTextBox14";
            this.gunaLineTextBox14.PasswordChar = '\0';
            this.gunaLineTextBox14.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox14.TabIndex = 6;
            this.gunaLineTextBox14.Text = "Insert the guild ID here.";
            this.gunaLineTextBox14.TextOffsetX = 0;
            // 
            // metroLabel9
            // 
            this.metroLabel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel9.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel9.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(931, 23);
            this.metroLabel9.TabIndex = 1;
            this.metroLabel9.Text = "Voice Spammer";
            this.metroLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bunifuHSlider10
            // 
            this.bunifuHSlider10.AllowCursorChanges = true;
            this.bunifuHSlider10.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider10.AllowIncrementalClickMoves = true;
            this.bunifuHSlider10.AllowMouseDownEffects = false;
            this.bunifuHSlider10.AllowMouseHoverEffects = false;
            this.bunifuHSlider10.AllowScrollingAnimations = true;
            this.bunifuHSlider10.AllowScrollKeysDetection = true;
            this.bunifuHSlider10.AllowScrollOptionsMenu = true;
            this.bunifuHSlider10.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider10.BackgroundImage")));
            this.bunifuHSlider10.BindingContainer = null;
            this.bunifuHSlider10.BorderRadius = 2;
            this.bunifuHSlider10.BorderThickness = 1;
            this.bunifuHSlider10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider10.DrawThickBorder = false;
            this.bunifuHSlider10.DurationBeforeShrink = 2000;
            this.bunifuHSlider10.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider10.LargeChange = 10;
            this.bunifuHSlider10.Location = new System.Drawing.Point(144, 349);
            this.bunifuHSlider10.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.bunifuHSlider10.Maximum = 5000;
            this.bunifuHSlider10.Minimum = 0;
            this.bunifuHSlider10.MinimumSize = new System.Drawing.Size(0, 54);
            this.bunifuHSlider10.MinimumThumbLength = 18;
            this.bunifuHSlider10.Name = "bunifuHSlider10";
            this.bunifuHSlider10.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider10.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider10.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider10.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider10.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider10.ShrinkSizeLimit = 3;
            this.bunifuHSlider10.Size = new System.Drawing.Size(641, 54);
            this.bunifuHSlider10.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider10.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider10.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider10.SmallChange = 1;
            this.bunifuHSlider10.TabIndex = 35;
            this.bunifuHSlider10.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider10.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider10.ThumbLength = 18;
            this.bunifuHSlider10.ThumbMargin = 1;
            this.bunifuHSlider10.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider10.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider10.Value = 0;
            this.bunifuHSlider10.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider10_Scroll);
            // 
            // bunifuHSlider9
            // 
            this.bunifuHSlider9.AllowCursorChanges = true;
            this.bunifuHSlider9.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider9.AllowIncrementalClickMoves = true;
            this.bunifuHSlider9.AllowMouseDownEffects = false;
            this.bunifuHSlider9.AllowMouseHoverEffects = false;
            this.bunifuHSlider9.AllowScrollingAnimations = true;
            this.bunifuHSlider9.AllowScrollKeysDetection = true;
            this.bunifuHSlider9.AllowScrollOptionsMenu = true;
            this.bunifuHSlider9.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider9.BackgroundImage")));
            this.bunifuHSlider9.BindingContainer = null;
            this.bunifuHSlider9.BorderRadius = 2;
            this.bunifuHSlider9.BorderThickness = 1;
            this.bunifuHSlider9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider9.DrawThickBorder = false;
            this.bunifuHSlider9.DurationBeforeShrink = 2000;
            this.bunifuHSlider9.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider9.LargeChange = 10;
            this.bunifuHSlider9.Location = new System.Drawing.Point(144, 257);
            this.bunifuHSlider9.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.bunifuHSlider9.Maximum = 5000;
            this.bunifuHSlider9.Minimum = 0;
            this.bunifuHSlider9.MinimumSize = new System.Drawing.Size(0, 54);
            this.bunifuHSlider9.MinimumThumbLength = 18;
            this.bunifuHSlider9.Name = "bunifuHSlider9";
            this.bunifuHSlider9.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider9.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider9.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider9.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider9.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider9.ShrinkSizeLimit = 3;
            this.bunifuHSlider9.Size = new System.Drawing.Size(641, 54);
            this.bunifuHSlider9.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider9.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider9.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider9.SmallChange = 1;
            this.bunifuHSlider9.TabIndex = 34;
            this.bunifuHSlider9.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider9.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider9.ThumbLength = 18;
            this.bunifuHSlider9.ThumbMargin = 1;
            this.bunifuHSlider9.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider9.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider9.Value = 0;
            this.bunifuHSlider9.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider9_Scroll);
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage10.Controls.Add(this.siticoneRadioButton9);
            this.tabPage10.Controls.Add(this.siticoneRadioButton10);
            this.tabPage10.Controls.Add(this.siticoneRadioButton11);
            this.tabPage10.Controls.Add(this.siticoneCheckBox27);
            this.tabPage10.Controls.Add(this.siticoneCheckBox22);
            this.tabPage10.Controls.Add(this.gunaButton18);
            this.tabPage10.Controls.Add(this.gunaButton17);
            this.tabPage10.Controls.Add(this.metroLabel27);
            this.tabPage10.Controls.Add(this.siticoneOSToggleSwith11);
            this.tabPage10.Controls.Add(this.gunaTextBox3);
            this.tabPage10.Controls.Add(this.gunaLineTextBox19);
            this.tabPage10.Controls.Add(this.gunaLineTextBox18);
            this.tabPage10.Controls.Add(this.gunaLineTextBox17);
            this.tabPage10.Controls.Add(this.metroLabel10);
            this.tabPage10.Controls.Add(this.bunifuHSlider11);
            this.tabPage10.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage10.Location = new System.Drawing.Point(184, 4);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(931, 581);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "Webhook Spammer";
            // 
            // siticoneRadioButton9
            // 
            this.siticoneRadioButton9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton9.AutoSize = true;
            this.siticoneRadioButton9.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton9.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton9.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton9.Location = new System.Drawing.Point(342, 425);
            this.siticoneRadioButton9.Name = "siticoneRadioButton9";
            this.siticoneRadioButton9.Size = new System.Drawing.Size(103, 17);
            this.siticoneRadioButton9.TabIndex = 40;
            this.siticoneRadioButton9.Text = "Supreme Mode";
            this.siticoneRadioButton9.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton9.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton9.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton9.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton9.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton10
            // 
            this.siticoneRadioButton10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton10.AutoSize = true;
            this.siticoneRadioButton10.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton10.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton10.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton10.Location = new System.Drawing.Point(342, 402);
            this.siticoneRadioButton10.Name = "siticoneRadioButton10";
            this.siticoneRadioButton10.Size = new System.Drawing.Size(98, 17);
            this.siticoneRadioButton10.TabIndex = 39;
            this.siticoneRadioButton10.Text = "Extreme Mode";
            this.siticoneRadioButton10.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton10.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton10.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton10.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton10.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton11
            // 
            this.siticoneRadioButton11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneRadioButton11.AutoSize = true;
            this.siticoneRadioButton11.Checked = true;
            this.siticoneRadioButton11.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneRadioButton11.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton11.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton11.Location = new System.Drawing.Point(342, 380);
            this.siticoneRadioButton11.Name = "siticoneRadioButton11";
            this.siticoneRadioButton11.Size = new System.Drawing.Size(95, 17);
            this.siticoneRadioButton11.TabIndex = 38;
            this.siticoneRadioButton11.TabStop = true;
            this.siticoneRadioButton11.Text = "Normal Mode";
            this.siticoneRadioButton11.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton11.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton11.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton11.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton11.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox27
            // 
            this.siticoneCheckBox27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox27.AutoSize = true;
            this.siticoneCheckBox27.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox27.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox27.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox27.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox27.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox27.Location = new System.Drawing.Point(144, 405);
            this.siticoneCheckBox27.Name = "siticoneCheckBox27";
            this.siticoneCheckBox27.Size = new System.Drawing.Size(122, 17);
            this.siticoneCheckBox27.TabIndex = 37;
            this.siticoneCheckBox27.Text = "Multiple Messages";
            this.siticoneCheckBox27.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox27.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox27.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox27.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox27.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox22
            // 
            this.siticoneCheckBox22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox22.AutoSize = true;
            this.siticoneCheckBox22.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox22.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox22.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox22.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox22.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox22.Location = new System.Drawing.Point(144, 382);
            this.siticoneCheckBox22.Name = "siticoneCheckBox22";
            this.siticoneCheckBox22.Size = new System.Drawing.Size(128, 17);
            this.siticoneCheckBox22.TabIndex = 36;
            this.siticoneCheckBox22.Text = "Multiple Webhooks";
            this.siticoneCheckBox22.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox22.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox22.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox22.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox22.UseVisualStyleBackColor = true;
            // 
            // gunaButton18
            // 
            this.gunaButton18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton18.Animated = true;
            this.gunaButton18.AnimationHoverSpeed = 0.07F;
            this.gunaButton18.AnimationSpeed = 0.03F;
            this.gunaButton18.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton18.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton18.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton18.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton18.Enabled = false;
            this.gunaButton18.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton18.ForeColor = System.Drawing.Color.White;
            this.gunaButton18.Image = null;
            this.gunaButton18.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton18.Location = new System.Drawing.Point(470, 515);
            this.gunaButton18.Name = "gunaButton18";
            this.gunaButton18.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton18.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton18.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton18.OnHoverImage = null;
            this.gunaButton18.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton18.Size = new System.Drawing.Size(317, 42);
            this.gunaButton18.TabIndex = 35;
            this.gunaButton18.Text = "Stop Spamming";
            this.gunaButton18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton18.Click += new System.EventHandler(this.gunaButton18_Click);
            // 
            // gunaButton17
            // 
            this.gunaButton17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton17.Animated = true;
            this.gunaButton17.AnimationHoverSpeed = 0.07F;
            this.gunaButton17.AnimationSpeed = 0.03F;
            this.gunaButton17.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton17.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton17.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton17.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton17.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton17.ForeColor = System.Drawing.Color.White;
            this.gunaButton17.Image = null;
            this.gunaButton17.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton17.Location = new System.Drawing.Point(144, 515);
            this.gunaButton17.Name = "gunaButton17";
            this.gunaButton17.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton17.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton17.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton17.OnHoverImage = null;
            this.gunaButton17.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton17.Size = new System.Drawing.Size(317, 42);
            this.gunaButton17.TabIndex = 34;
            this.gunaButton17.Text = "Start Spamming";
            this.gunaButton17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton17.Click += new System.EventHandler(this.gunaButton17_Click);
            // 
            // metroLabel27
            // 
            this.metroLabel27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel27.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel27.Location = new System.Drawing.Point(723, 381);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(64, 15);
            this.metroLabel27.TabIndex = 32;
            this.metroLabel27.Text = "Delay: 0ms";
            this.metroLabel27.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith11
            // 
            this.siticoneOSToggleSwith11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith11.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith11.Location = new System.Drawing.Point(683, 378);
            this.siticoneOSToggleSwith11.Name = "siticoneOSToggleSwith11";
            this.siticoneOSToggleSwith11.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith11.TabIndex = 31;
            // 
            // gunaTextBox3
            // 
            this.gunaTextBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaTextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox3.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox3.BorderSize = 1;
            this.gunaTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox3.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox3.FocusedBorderColor = System.Drawing.Color.Red;
            this.gunaTextBox3.FocusedForeColor = System.Drawing.Color.White;
            this.gunaTextBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox3.Location = new System.Drawing.Point(144, 224);
            this.gunaTextBox3.MaxLength = 2147483647;
            this.gunaTextBox3.MultiLine = true;
            this.gunaTextBox3.Name = "gunaTextBox3";
            this.gunaTextBox3.PasswordChar = '\0';
            this.gunaTextBox3.Size = new System.Drawing.Size(641, 137);
            this.gunaTextBox3.TabIndex = 10;
            this.gunaTextBox3.Text = "Insert the message here.";
            // 
            // gunaLineTextBox19
            // 
            this.gunaLineTextBox19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox19.Animated = true;
            this.gunaLineTextBox19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox19.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox19.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox19.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox19.LineSize = 1;
            this.gunaLineTextBox19.Location = new System.Drawing.Point(144, 192);
            this.gunaLineTextBox19.MaxLength = 2147483647;
            this.gunaLineTextBox19.Name = "gunaLineTextBox19";
            this.gunaLineTextBox19.PasswordChar = '\0';
            this.gunaLineTextBox19.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox19.TabIndex = 9;
            this.gunaLineTextBox19.Text = "Insert the avatar URL of the webhook here.";
            this.gunaLineTextBox19.TextOffsetX = 0;
            // 
            // gunaLineTextBox18
            // 
            this.gunaLineTextBox18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox18.Animated = true;
            this.gunaLineTextBox18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox18.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox18.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox18.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox18.LineSize = 1;
            this.gunaLineTextBox18.Location = new System.Drawing.Point(144, 160);
            this.gunaLineTextBox18.MaxLength = 2147483647;
            this.gunaLineTextBox18.Name = "gunaLineTextBox18";
            this.gunaLineTextBox18.PasswordChar = '\0';
            this.gunaLineTextBox18.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox18.TabIndex = 8;
            this.gunaLineTextBox18.Text = "Insert the username of the webhook here.";
            this.gunaLineTextBox18.TextOffsetX = 0;
            // 
            // gunaLineTextBox17
            // 
            this.gunaLineTextBox17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox17.Animated = true;
            this.gunaLineTextBox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox17.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox17.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox17.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox17.LineSize = 1;
            this.gunaLineTextBox17.Location = new System.Drawing.Point(144, 128);
            this.gunaLineTextBox17.MaxLength = 2147483647;
            this.gunaLineTextBox17.Name = "gunaLineTextBox17";
            this.gunaLineTextBox17.PasswordChar = '\0';
            this.gunaLineTextBox17.Size = new System.Drawing.Size(641, 26);
            this.gunaLineTextBox17.TabIndex = 7;
            this.gunaLineTextBox17.Text = "Insert the webhook link here.";
            this.gunaLineTextBox17.TextOffsetX = 0;
            // 
            // metroLabel10
            // 
            this.metroLabel10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel10.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel10.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(931, 23);
            this.metroLabel10.TabIndex = 1;
            this.metroLabel10.Text = "Webhook Spammer";
            this.metroLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bunifuHSlider11
            // 
            this.bunifuHSlider11.AllowCursorChanges = true;
            this.bunifuHSlider11.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider11.AllowIncrementalClickMoves = true;
            this.bunifuHSlider11.AllowMouseDownEffects = false;
            this.bunifuHSlider11.AllowMouseHoverEffects = false;
            this.bunifuHSlider11.AllowScrollingAnimations = true;
            this.bunifuHSlider11.AllowScrollKeysDetection = true;
            this.bunifuHSlider11.AllowScrollOptionsMenu = true;
            this.bunifuHSlider11.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider11.BackgroundImage")));
            this.bunifuHSlider11.BindingContainer = null;
            this.bunifuHSlider11.BorderRadius = 2;
            this.bunifuHSlider11.BorderThickness = 1;
            this.bunifuHSlider11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider11.DrawThickBorder = false;
            this.bunifuHSlider11.DurationBeforeShrink = 2000;
            this.bunifuHSlider11.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider11.LargeChange = 10;
            this.bunifuHSlider11.Location = new System.Drawing.Point(144, 453);
            this.bunifuHSlider11.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.bunifuHSlider11.Maximum = 5000;
            this.bunifuHSlider11.Minimum = 0;
            this.bunifuHSlider11.MinimumSize = new System.Drawing.Size(0, 54);
            this.bunifuHSlider11.MinimumThumbLength = 18;
            this.bunifuHSlider11.Name = "bunifuHSlider11";
            this.bunifuHSlider11.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider11.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider11.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider11.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider11.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider11.ShrinkSizeLimit = 3;
            this.bunifuHSlider11.Size = new System.Drawing.Size(643, 54);
            this.bunifuHSlider11.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider11.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider11.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider11.SmallChange = 1;
            this.bunifuHSlider11.TabIndex = 33;
            this.bunifuHSlider11.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider11.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider11.ThumbLength = 18;
            this.bunifuHSlider11.ThumbMargin = 1;
            this.bunifuHSlider11.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider11.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider11.Value = 0;
            this.bunifuHSlider11.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider11_Scroll);
            // 
            // tabPage11
            // 
            this.tabPage11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage11.Controls.Add(this.siticoneCheckBox28);
            this.tabPage11.Controls.Add(this.metroLabel8);
            this.tabPage11.Controls.Add(this.gunaButton20);
            this.tabPage11.Controls.Add(this.gunaButton19);
            this.tabPage11.Controls.Add(this.metroLabel28);
            this.tabPage11.Controls.Add(this.siticoneOSToggleSwith12);
            this.tabPage11.Controls.Add(this.gunaTextBox4);
            this.tabPage11.Controls.Add(this.metroLabel11);
            this.tabPage11.Controls.Add(this.bunifuHSlider12);
            this.tabPage11.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage11.Location = new System.Drawing.Point(184, 4);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(931, 581);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "Mass DM Advertiser";
            // 
            // siticoneCheckBox28
            // 
            this.siticoneCheckBox28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox28.AutoSize = true;
            this.siticoneCheckBox28.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox28.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox28.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox28.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox28.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox28.Location = new System.Drawing.Point(144, 286);
            this.siticoneCheckBox28.Name = "siticoneCheckBox28";
            this.siticoneCheckBox28.Size = new System.Drawing.Size(122, 17);
            this.siticoneCheckBox28.TabIndex = 37;
            this.siticoneCheckBox28.Text = "Multiple Messages";
            this.siticoneCheckBox28.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox28.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox28.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox28.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox28.UseVisualStyleBackColor = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel8.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel8.Location = new System.Drawing.Point(0, 460);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(931, 23);
            this.metroLabel8.TabIndex = 36;
            this.metroLabel8.Text = "Parsed users: 0, completed users: 0";
            this.metroLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // gunaButton20
            // 
            this.gunaButton20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton20.Animated = true;
            this.gunaButton20.AnimationHoverSpeed = 0.07F;
            this.gunaButton20.AnimationSpeed = 0.03F;
            this.gunaButton20.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton20.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton20.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton20.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton20.Enabled = false;
            this.gunaButton20.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton20.ForeColor = System.Drawing.Color.White;
            this.gunaButton20.Image = null;
            this.gunaButton20.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton20.Location = new System.Drawing.Point(468, 409);
            this.gunaButton20.Name = "gunaButton20";
            this.gunaButton20.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton20.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton20.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton20.OnHoverImage = null;
            this.gunaButton20.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton20.Size = new System.Drawing.Size(317, 42);
            this.gunaButton20.TabIndex = 35;
            this.gunaButton20.Text = "Stop Advertising";
            this.gunaButton20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton20.Click += new System.EventHandler(this.gunaButton20_Click);
            // 
            // gunaButton19
            // 
            this.gunaButton19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton19.Animated = true;
            this.gunaButton19.AnimationHoverSpeed = 0.07F;
            this.gunaButton19.AnimationSpeed = 0.03F;
            this.gunaButton19.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton19.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton19.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton19.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton19.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton19.ForeColor = System.Drawing.Color.White;
            this.gunaButton19.Image = null;
            this.gunaButton19.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton19.Location = new System.Drawing.Point(144, 409);
            this.gunaButton19.Name = "gunaButton19";
            this.gunaButton19.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton19.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton19.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton19.OnHoverImage = null;
            this.gunaButton19.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton19.Size = new System.Drawing.Size(317, 42);
            this.gunaButton19.TabIndex = 34;
            this.gunaButton19.Text = "Start Advertising";
            this.gunaButton19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton19.Click += new System.EventHandler(this.gunaButton19_Click);
            // 
            // metroLabel28
            // 
            this.metroLabel28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel28.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel28.Location = new System.Drawing.Point(724, 286);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(64, 15);
            this.metroLabel28.TabIndex = 32;
            this.metroLabel28.Text = "Delay: 0ms";
            this.metroLabel28.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // siticoneOSToggleSwith12
            // 
            this.siticoneOSToggleSwith12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneOSToggleSwith12.CheckedFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneOSToggleSwith12.Location = new System.Drawing.Point(684, 283);
            this.siticoneOSToggleSwith12.Name = "siticoneOSToggleSwith12";
            this.siticoneOSToggleSwith12.Size = new System.Drawing.Size(38, 22);
            this.siticoneOSToggleSwith12.TabIndex = 31;
            // 
            // gunaTextBox4
            // 
            this.gunaTextBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaTextBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox4.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox4.BorderSize = 1;
            this.gunaTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox4.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox4.FocusedBorderColor = System.Drawing.Color.Red;
            this.gunaTextBox4.FocusedForeColor = System.Drawing.Color.White;
            this.gunaTextBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox4.Location = new System.Drawing.Point(144, 128);
            this.gunaTextBox4.MaxLength = 2147483647;
            this.gunaTextBox4.MultiLine = true;
            this.gunaTextBox4.Name = "gunaTextBox4";
            this.gunaTextBox4.PasswordChar = '\0';
            this.gunaTextBox4.Size = new System.Drawing.Size(641, 137);
            this.gunaTextBox4.TabIndex = 7;
            this.gunaTextBox4.Text = "Insert the message here.";
            // 
            // metroLabel11
            // 
            this.metroLabel11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel11.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel11.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(931, 23);
            this.metroLabel11.TabIndex = 1;
            this.metroLabel11.Text = "Mass DM Advertiser";
            this.metroLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bunifuHSlider12
            // 
            this.bunifuHSlider12.AllowCursorChanges = true;
            this.bunifuHSlider12.AllowHomeEndKeysDetection = false;
            this.bunifuHSlider12.AllowIncrementalClickMoves = true;
            this.bunifuHSlider12.AllowMouseDownEffects = false;
            this.bunifuHSlider12.AllowMouseHoverEffects = false;
            this.bunifuHSlider12.AllowScrollingAnimations = true;
            this.bunifuHSlider12.AllowScrollKeysDetection = true;
            this.bunifuHSlider12.AllowScrollOptionsMenu = true;
            this.bunifuHSlider12.AllowShrinkingOnFocusLost = false;
            this.bunifuHSlider12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuHSlider12.BackColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuHSlider12.BackgroundImage")));
            this.bunifuHSlider12.BindingContainer = null;
            this.bunifuHSlider12.BorderRadius = 2;
            this.bunifuHSlider12.BorderThickness = 1;
            this.bunifuHSlider12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuHSlider12.DrawThickBorder = false;
            this.bunifuHSlider12.DurationBeforeShrink = 2000;
            this.bunifuHSlider12.ElapsedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider12.LargeChange = 10;
            this.bunifuHSlider12.Location = new System.Drawing.Point(144, 330);
            this.bunifuHSlider12.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.bunifuHSlider12.Maximum = 5000;
            this.bunifuHSlider12.Minimum = 0;
            this.bunifuHSlider12.MinimumSize = new System.Drawing.Size(0, 54);
            this.bunifuHSlider12.MinimumThumbLength = 18;
            this.bunifuHSlider12.Name = "bunifuHSlider12";
            this.bunifuHSlider12.OnDisable.ScrollBarBorderColor = System.Drawing.Color.Silver;
            this.bunifuHSlider12.OnDisable.ScrollBarColor = System.Drawing.Color.Transparent;
            this.bunifuHSlider12.OnDisable.ThumbColor = System.Drawing.Color.Silver;
            this.bunifuHSlider12.ScrollBarBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider12.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider12.ShrinkSizeLimit = 3;
            this.bunifuHSlider12.Size = new System.Drawing.Size(644, 54);
            this.bunifuHSlider12.SliderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.bunifuHSlider12.SliderStyle = Bunifu.UI.WinForms.BunifuHSlider.SliderStyles.Thin;
            this.bunifuHSlider12.SliderThumbStyle = Utilities.BunifuSlider.BunifuHScrollBar.SliderThumbStyles.Circular;
            this.bunifuHSlider12.SmallChange = 1;
            this.bunifuHSlider12.TabIndex = 33;
            this.bunifuHSlider12.ThumbColor = System.Drawing.Color.Red;
            this.bunifuHSlider12.ThumbFillColor = System.Drawing.Color.Red;
            this.bunifuHSlider12.ThumbLength = 18;
            this.bunifuHSlider12.ThumbMargin = 1;
            this.bunifuHSlider12.ThumbSize = Bunifu.UI.WinForms.BunifuHSlider.ThumbSizes.Medium;
            this.bunifuHSlider12.ThumbStyle = Bunifu.UI.WinForms.BunifuHSlider.ThumbStyles.Fill;
            this.bunifuHSlider12.Value = 0;
            this.bunifuHSlider12.Scroll += new System.EventHandler<Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs>(this.bunifuHSlider12_Scroll);
            // 
            // tabPage12
            // 
            this.tabPage12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage12.Controls.Add(this.siticoneCheckBox32);
            this.tabPage12.Controls.Add(this.siticoneCheckBox31);
            this.tabPage12.Controls.Add(this.siticoneCheckBox30);
            this.tabPage12.Controls.Add(this.siticoneComboBox1);
            this.tabPage12.Controls.Add(this.siticoneButton9);
            this.tabPage12.Controls.Add(this.siticoneCheckBox26);
            this.tabPage12.Controls.Add(this.siticoneCheckBox25);
            this.tabPage12.Controls.Add(this.siticoneCheckBox24);
            this.tabPage12.Controls.Add(this.siticoneCheckBox10);
            this.tabPage12.Controls.Add(this.siticoneCheckBox6);
            this.tabPage12.Controls.Add(this.gunaLineTextBox13);
            this.tabPage12.Controls.Add(this.gunaTextBox5);
            this.tabPage12.Controls.Add(this.siticoneButton12);
            this.tabPage12.Controls.Add(this.siticoneComboBox2);
            this.tabPage12.Controls.Add(this.siticoneButton11);
            this.tabPage12.Controls.Add(this.siticoneButton8);
            this.tabPage12.Controls.Add(this.gunaLineTextBox22);
            this.tabPage12.Controls.Add(this.gunaLineTextBox21);
            this.tabPage12.Controls.Add(this.gunaLinkLabel1);
            this.tabPage12.Controls.Add(this.gunaLineTextBox20);
            this.tabPage12.Controls.Add(this.metroLabel12);
            this.tabPage12.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage12.Location = new System.Drawing.Point(184, 4);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(931, 581);
            this.tabPage12.TabIndex = 11;
            this.tabPage12.Text = "Settings and Utils";
            // 
            // siticoneCheckBox32
            // 
            this.siticoneCheckBox32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox32.AutoSize = true;
            this.siticoneCheckBox32.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox32.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox32.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox32.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox32.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox32.Location = new System.Drawing.Point(565, 407);
            this.siticoneCheckBox32.Name = "siticoneCheckBox32";
            this.siticoneCheckBox32.Size = new System.Drawing.Size(113, 17);
            this.siticoneCheckBox32.TabIndex = 33;
            this.siticoneCheckBox32.Text = "Mention all roles";
            this.siticoneCheckBox32.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox32.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox32.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox32.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox32.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox31
            // 
            this.siticoneCheckBox31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox31.AutoSize = true;
            this.siticoneCheckBox31.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox31.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox31.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox31.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox31.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox31.Location = new System.Drawing.Point(783, 384);
            this.siticoneCheckBox31.Name = "siticoneCheckBox31";
            this.siticoneCheckBox31.Size = new System.Drawing.Size(98, 17);
            this.siticoneCheckBox31.TabIndex = 32;
            this.siticoneCheckBox31.Text = "Mention roles";
            this.siticoneCheckBox31.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox31.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox31.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox31.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox31.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox30
            // 
            this.siticoneCheckBox30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox30.AutoSize = true;
            this.siticoneCheckBox30.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox30.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox30.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox30.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox30.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox30.Location = new System.Drawing.Point(662, 384);
            this.siticoneCheckBox30.Name = "siticoneCheckBox30";
            this.siticoneCheckBox30.Size = new System.Drawing.Size(115, 17);
            this.siticoneCheckBox30.TabIndex = 31;
            this.siticoneCheckBox30.Text = "Mention all users";
            this.siticoneCheckBox30.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox30.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox30.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox30.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox30.UseVisualStyleBackColor = true;
            // 
            // siticoneComboBox1
            // 
            this.siticoneComboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.siticoneComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.siticoneComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.siticoneComboBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.siticoneComboBox1.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneComboBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.siticoneComboBox1.ForeColor = System.Drawing.Color.White;
            this.siticoneComboBox1.FormattingEnabled = true;
            this.siticoneComboBox1.HoveredState.Parent = this.siticoneComboBox1;
            this.siticoneComboBox1.ItemHeight = 30;
            this.siticoneComboBox1.Items.AddRange(new object[] {
            "HypeSquad Balance",
            "HypeSquad Bravery",
            "HypeSquad Brilliance"});
            this.siticoneComboBox1.ItemsAppearance.Parent = this.siticoneComboBox1;
            this.siticoneComboBox1.Location = new System.Drawing.Point(38, 238);
            this.siticoneComboBox1.Name = "siticoneComboBox1";
            this.siticoneComboBox1.ShadowDecoration.Parent = this.siticoneComboBox1;
            this.siticoneComboBox1.Size = new System.Drawing.Size(341, 36);
            this.siticoneComboBox1.TabIndex = 30;
            // 
            // siticoneButton9
            // 
            this.siticoneButton9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton9.BorderRadius = 15;
            this.siticoneButton9.CheckedState.Parent = this.siticoneButton9;
            this.siticoneButton9.CustomImages.Parent = this.siticoneButton9;
            this.siticoneButton9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton9.ForeColor = System.Drawing.Color.White;
            this.siticoneButton9.HoveredState.Parent = this.siticoneButton9;
            this.siticoneButton9.Location = new System.Drawing.Point(38, 292);
            this.siticoneButton9.Name = "siticoneButton9";
            this.siticoneButton9.ShadowDecoration.Parent = this.siticoneButton9;
            this.siticoneButton9.Size = new System.Drawing.Size(341, 45);
            this.siticoneButton9.TabIndex = 29;
            this.siticoneButton9.Text = "Set new HypeSquad for all tokens";
            this.siticoneButton9.Click += new System.EventHandler(this.siticoneButton9_Click);
            // 
            // siticoneCheckBox26
            // 
            this.siticoneCheckBox26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox26.AutoSize = true;
            this.siticoneCheckBox26.Checked = true;
            this.siticoneCheckBox26.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox26.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox26.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox26.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox26.CheckState = System.Windows.Forms.CheckState.Checked;
            this.siticoneCheckBox26.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox26.Location = new System.Drawing.Point(684, 407);
            this.siticoneCheckBox26.Name = "siticoneCheckBox26";
            this.siticoneCheckBox26.Size = new System.Drawing.Size(118, 17);
            this.siticoneCheckBox26.TabIndex = 28;
            this.siticoneCheckBox26.Text = "Copy to clipboard";
            this.siticoneCheckBox26.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox26.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox26.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox26.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox26.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox25
            // 
            this.siticoneCheckBox25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox25.AutoSize = true;
            this.siticoneCheckBox25.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox25.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox25.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox25.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox25.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox25.Location = new System.Drawing.Point(565, 384);
            this.siticoneCheckBox25.Name = "siticoneCheckBox25";
            this.siticoneCheckBox25.Size = new System.Drawing.Size(91, 17);
            this.siticoneCheckBox25.TabIndex = 27;
            this.siticoneCheckBox25.Text = "Lag message";
            this.siticoneCheckBox25.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox25.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox25.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox25.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox25.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox24
            // 
            this.siticoneCheckBox24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox24.AutoSize = true;
            this.siticoneCheckBox24.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox24.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox24.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox24.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox24.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox24.Location = new System.Drawing.Point(791, 361);
            this.siticoneCheckBox24.Name = "siticoneCheckBox24";
            this.siticoneCheckBox24.Size = new System.Drawing.Size(123, 17);
            this.siticoneCheckBox24.TabIndex = 26;
            this.siticoneCheckBox24.Text = "Mass mention user";
            this.siticoneCheckBox24.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox24.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox24.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox24.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox24.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox10
            // 
            this.siticoneCheckBox10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox10.AutoSize = true;
            this.siticoneCheckBox10.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox10.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox10.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox10.Location = new System.Drawing.Point(683, 361);
            this.siticoneCheckBox10.Name = "siticoneCheckBox10";
            this.siticoneCheckBox10.Size = new System.Drawing.Size(102, 17);
            this.siticoneCheckBox10.TabIndex = 25;
            this.siticoneCheckBox10.Text = "Random string";
            this.siticoneCheckBox10.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox10.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox10.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox10.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox10.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox6
            // 
            this.siticoneCheckBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneCheckBox6.AutoSize = true;
            this.siticoneCheckBox6.CheckedState.BorderColor = System.Drawing.Color.Red;
            this.siticoneCheckBox6.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox6.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox6.Location = new System.Drawing.Point(565, 361);
            this.siticoneCheckBox6.Name = "siticoneCheckBox6";
            this.siticoneCheckBox6.Size = new System.Drawing.Size(112, 17);
            this.siticoneCheckBox6.TabIndex = 24;
            this.siticoneCheckBox6.Text = "Random number";
            this.siticoneCheckBox6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox6.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox6.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox6.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox6.UseVisualStyleBackColor = true;
            // 
            // gunaLineTextBox13
            // 
            this.gunaLineTextBox13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox13.Animated = true;
            this.gunaLineTextBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox13.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox13.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox13.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox13.LineSize = 1;
            this.gunaLineTextBox13.Location = new System.Drawing.Point(565, 183);
            this.gunaLineTextBox13.MaxLength = 8;
            this.gunaLineTextBox13.Name = "gunaLineTextBox13";
            this.gunaLineTextBox13.PasswordChar = '\0';
            this.gunaLineTextBox13.Size = new System.Drawing.Size(341, 26);
            this.gunaLineTextBox13.TabIndex = 23;
            this.gunaLineTextBox13.Text = "Insert the number of placeholders here.";
            this.gunaLineTextBox13.TextOffsetX = 0;
            // 
            // gunaTextBox5
            // 
            this.gunaTextBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaTextBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox5.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox5.BorderSize = 1;
            this.gunaTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox5.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox5.FocusedBorderColor = System.Drawing.Color.Red;
            this.gunaTextBox5.FocusedForeColor = System.Drawing.Color.White;
            this.gunaTextBox5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox5.Location = new System.Drawing.Point(565, 215);
            this.gunaTextBox5.MaxLength = 2147483647;
            this.gunaTextBox5.MultiLine = true;
            this.gunaTextBox5.Name = "gunaTextBox5";
            this.gunaTextBox5.PasswordChar = '\0';
            this.gunaTextBox5.ReadOnly = true;
            this.gunaTextBox5.Size = new System.Drawing.Size(341, 137);
            this.gunaTextBox5.TabIndex = 22;
            // 
            // siticoneButton12
            // 
            this.siticoneButton12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton12.BorderRadius = 15;
            this.siticoneButton12.CheckedState.Parent = this.siticoneButton12;
            this.siticoneButton12.CustomImages.Parent = this.siticoneButton12;
            this.siticoneButton12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton12.ForeColor = System.Drawing.Color.White;
            this.siticoneButton12.HoveredState.Parent = this.siticoneButton12;
            this.siticoneButton12.Location = new System.Drawing.Point(565, 432);
            this.siticoneButton12.Name = "siticoneButton12";
            this.siticoneButton12.ShadowDecoration.Parent = this.siticoneButton12;
            this.siticoneButton12.Size = new System.Drawing.Size(341, 45);
            this.siticoneButton12.TabIndex = 21;
            this.siticoneButton12.Text = "Generate Text";
            this.siticoneButton12.Click += new System.EventHandler(this.siticoneButton12_Click);
            // 
            // siticoneComboBox2
            // 
            this.siticoneComboBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneComboBox2.BackColor = System.Drawing.Color.Transparent;
            this.siticoneComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.siticoneComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.siticoneComboBox2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.siticoneComboBox2.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneComboBox2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.siticoneComboBox2.ForeColor = System.Drawing.Color.White;
            this.siticoneComboBox2.FormattingEnabled = true;
            this.siticoneComboBox2.HoveredState.Parent = this.siticoneComboBox2;
            this.siticoneComboBox2.ItemHeight = 30;
            this.siticoneComboBox2.Items.AddRange(new object[] {
            "Online",
            "Idle",
            "Do Not Disturb",
            "Invisible"});
            this.siticoneComboBox2.ItemsAppearance.Parent = this.siticoneComboBox2;
            this.siticoneComboBox2.Location = new System.Drawing.Point(38, 128);
            this.siticoneComboBox2.Name = "siticoneComboBox2";
            this.siticoneComboBox2.ShadowDecoration.Parent = this.siticoneComboBox2;
            this.siticoneComboBox2.Size = new System.Drawing.Size(341, 36);
            this.siticoneComboBox2.TabIndex = 20;
            // 
            // siticoneButton11
            // 
            this.siticoneButton11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton11.BorderRadius = 15;
            this.siticoneButton11.CheckedState.Parent = this.siticoneButton11;
            this.siticoneButton11.CustomImages.Parent = this.siticoneButton11;
            this.siticoneButton11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton11.ForeColor = System.Drawing.Color.White;
            this.siticoneButton11.HoveredState.Parent = this.siticoneButton11;
            this.siticoneButton11.Location = new System.Drawing.Point(38, 182);
            this.siticoneButton11.Name = "siticoneButton11";
            this.siticoneButton11.ShadowDecoration.Parent = this.siticoneButton11;
            this.siticoneButton11.Size = new System.Drawing.Size(341, 45);
            this.siticoneButton11.TabIndex = 19;
            this.siticoneButton11.Text = "Set new online status for all tokens";
            this.siticoneButton11.Click += new System.EventHandler(this.siticoneButton11_Click);
            // 
            // siticoneButton8
            // 
            this.siticoneButton8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton8.BorderRadius = 15;
            this.siticoneButton8.CheckedState.Parent = this.siticoneButton8;
            this.siticoneButton8.CustomImages.Parent = this.siticoneButton8;
            this.siticoneButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton8.ForeColor = System.Drawing.Color.White;
            this.siticoneButton8.HoveredState.Parent = this.siticoneButton8;
            this.siticoneButton8.Location = new System.Drawing.Point(565, 131);
            this.siticoneButton8.Name = "siticoneButton8";
            this.siticoneButton8.ShadowDecoration.Parent = this.siticoneButton8;
            this.siticoneButton8.Size = new System.Drawing.Size(341, 45);
            this.siticoneButton8.TabIndex = 13;
            this.siticoneButton8.Text = "Set new nickname for all tokens";
            this.siticoneButton8.Click += new System.EventHandler(this.siticoneButton8_Click);
            // 
            // gunaLineTextBox22
            // 
            this.gunaLineTextBox22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox22.Animated = true;
            this.gunaLineTextBox22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox22.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox22.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox22.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox22.LineSize = 1;
            this.gunaLineTextBox22.Location = new System.Drawing.Point(565, 93);
            this.gunaLineTextBox22.MaxLength = 2147483647;
            this.gunaLineTextBox22.Name = "gunaLineTextBox22";
            this.gunaLineTextBox22.PasswordChar = '\0';
            this.gunaLineTextBox22.Size = new System.Drawing.Size(341, 26);
            this.gunaLineTextBox22.TabIndex = 10;
            this.gunaLineTextBox22.Text = "Insert the new nickname/game here.";
            this.gunaLineTextBox22.TextOffsetX = 0;
            // 
            // gunaLineTextBox21
            // 
            this.gunaLineTextBox21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox21.Animated = true;
            this.gunaLineTextBox21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox21.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox21.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox21.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox21.LineSize = 1;
            this.gunaLineTextBox21.Location = new System.Drawing.Point(565, 61);
            this.gunaLineTextBox21.MaxLength = 2147483647;
            this.gunaLineTextBox21.Name = "gunaLineTextBox21";
            this.gunaLineTextBox21.PasswordChar = '\0';
            this.gunaLineTextBox21.Size = new System.Drawing.Size(341, 26);
            this.gunaLineTextBox21.TabIndex = 9;
            this.gunaLineTextBox21.Text = "Insert the guild id here.";
            this.gunaLineTextBox21.TextOffsetX = 0;
            // 
            // gunaLinkLabel1
            // 
            this.gunaLinkLabel1.ActiveLinkColor = System.Drawing.Color.Gold;
            this.gunaLinkLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLinkLabel1.AutoSize = true;
            this.gunaLinkLabel1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLinkLabel1.LinkColor = System.Drawing.Color.Yellow;
            this.gunaLinkLabel1.Location = new System.Drawing.Point(35, 96);
            this.gunaLinkLabel1.Name = "gunaLinkLabel1";
            this.gunaLinkLabel1.Size = new System.Drawing.Size(127, 15);
            this.gunaLinkLabel1.TabIndex = 8;
            this.gunaLinkLabel1.TabStop = true;
            this.gunaLinkLabel1.Text = "https://2captcha.com/";
            this.gunaLinkLabel1.TextRenderingHint = Guna.UI.WinForms.DrawingTextRenderingHint.AntiAlias;
            this.gunaLinkLabel1.VisitedLinkColor = System.Drawing.Color.Yellow;
            this.gunaLinkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.gunaLinkLabel1_LinkClicked);
            // 
            // gunaLineTextBox20
            // 
            this.gunaLineTextBox20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox20.Animated = true;
            this.gunaLineTextBox20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox20.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox20.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox20.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox20.LineSize = 1;
            this.gunaLineTextBox20.Location = new System.Drawing.Point(38, 61);
            this.gunaLineTextBox20.MaxLength = 2147483647;
            this.gunaLineTextBox20.Name = "gunaLineTextBox20";
            this.gunaLineTextBox20.PasswordChar = '\0';
            this.gunaLineTextBox20.Size = new System.Drawing.Size(341, 26);
            this.gunaLineTextBox20.TabIndex = 7;
            this.gunaLineTextBox20.Text = "Insert the 2Captcha.com key here.";
            this.gunaLineTextBox20.TextOffsetX = 0;
            // 
            // metroLabel12
            // 
            this.metroLabel12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel12.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel12.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(931, 23);
            this.metroLabel12.TabIndex = 1;
            this.metroLabel12.Text = "Settings and Utils";
            this.metroLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage8.Controls.Add(this.siticoneButton23);
            this.tabPage8.Controls.Add(this.siticoneButton22);
            this.tabPage8.Controls.Add(this.siticoneButton21);
            this.tabPage8.Controls.Add(this.pictureBox2);
            this.tabPage8.Controls.Add(this.siticoneButton20);
            this.tabPage8.Controls.Add(this.gunaLineTextBox29);
            this.tabPage8.Controls.Add(this.siticoneButton19);
            this.tabPage8.Controls.Add(this.gunaLineTextBox28);
            this.tabPage8.Controls.Add(this.siticoneButton18);
            this.tabPage8.Controls.Add(this.siticoneButton15);
            this.tabPage8.Controls.Add(this.siticoneButton16);
            this.tabPage8.Controls.Add(this.metroLabel33);
            this.tabPage8.Controls.Add(this.metroLabel34);
            this.tabPage8.Controls.Add(this.siticoneButton17);
            this.tabPage8.Controls.Add(this.gunaLineTextBox27);
            this.tabPage8.Controls.Add(this.siticoneButton14);
            this.tabPage8.Controls.Add(this.siticoneButton13);
            this.tabPage8.Controls.Add(this.metroLabel32);
            this.tabPage8.Controls.Add(this.metroLabel31);
            this.tabPage8.Controls.Add(this.siticoneButton10);
            this.tabPage8.Controls.Add(this.gunaLineTextBox24);
            this.tabPage8.Controls.Add(this.gunaLineTextBox25);
            this.tabPage8.Controls.Add(this.metroLabel29);
            this.tabPage8.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage8.Location = new System.Drawing.Point(184, 4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(931, 581);
            this.tabPage8.TabIndex = 12;
            this.tabPage8.Text = "Miscellaneous";
            // 
            // siticoneButton23
            // 
            this.siticoneButton23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton23.BorderRadius = 15;
            this.siticoneButton23.CheckedState.Parent = this.siticoneButton23;
            this.siticoneButton23.CustomImages.Parent = this.siticoneButton23;
            this.siticoneButton23.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton23.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton23.ForeColor = System.Drawing.Color.White;
            this.siticoneButton23.HoveredState.Parent = this.siticoneButton23;
            this.siticoneButton23.Location = new System.Drawing.Point(615, 526);
            this.siticoneButton23.Name = "siticoneButton23";
            this.siticoneButton23.ShadowDecoration.Parent = this.siticoneButton23;
            this.siticoneButton23.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton23.TabIndex = 40;
            this.siticoneButton23.Text = "Reset avatar for all tokens";
            this.siticoneButton23.Click += new System.EventHandler(this.siticoneButton23_Click);
            // 
            // siticoneButton22
            // 
            this.siticoneButton22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton22.BorderRadius = 15;
            this.siticoneButton22.CheckedState.Parent = this.siticoneButton22;
            this.siticoneButton22.CustomImages.Parent = this.siticoneButton22;
            this.siticoneButton22.Enabled = false;
            this.siticoneButton22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton22.ForeColor = System.Drawing.Color.White;
            this.siticoneButton22.HoveredState.Parent = this.siticoneButton22;
            this.siticoneButton22.Location = new System.Drawing.Point(615, 475);
            this.siticoneButton22.Name = "siticoneButton22";
            this.siticoneButton22.ShadowDecoration.Parent = this.siticoneButton22;
            this.siticoneButton22.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton22.TabIndex = 39;
            this.siticoneButton22.Text = "Set new avatar image for all tokens";
            this.siticoneButton22.Click += new System.EventHandler(this.siticoneButton22_Click);
            // 
            // siticoneButton21
            // 
            this.siticoneButton21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton21.BorderRadius = 15;
            this.siticoneButton21.CheckedState.Parent = this.siticoneButton21;
            this.siticoneButton21.CustomImages.Parent = this.siticoneButton21;
            this.siticoneButton21.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton21.ForeColor = System.Drawing.Color.White;
            this.siticoneButton21.HoveredState.Parent = this.siticoneButton21;
            this.siticoneButton21.Location = new System.Drawing.Point(615, 424);
            this.siticoneButton21.Name = "siticoneButton21";
            this.siticoneButton21.ShadowDecoration.Parent = this.siticoneButton21;
            this.siticoneButton21.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton21.TabIndex = 38;
            this.siticoneButton21.Text = "Import new avatar image from file";
            this.siticoneButton21.Click += new System.EventHandler(this.siticoneButton21_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(702, 281);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(128, 128);
            this.pictureBox2.TabIndex = 37;
            this.pictureBox2.TabStop = false;
            // 
            // siticoneButton20
            // 
            this.siticoneButton20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton20.BorderRadius = 15;
            this.siticoneButton20.CheckedState.Parent = this.siticoneButton20;
            this.siticoneButton20.CustomImages.Parent = this.siticoneButton20;
            this.siticoneButton20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton20.ForeColor = System.Drawing.Color.White;
            this.siticoneButton20.HoveredState.Parent = this.siticoneButton20;
            this.siticoneButton20.Location = new System.Drawing.Point(14, 517);
            this.siticoneButton20.Name = "siticoneButton20";
            this.siticoneButton20.ShadowDecoration.Parent = this.siticoneButton20;
            this.siticoneButton20.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton20.TabIndex = 36;
            this.siticoneButton20.Text = "Set new custom status for all tokens";
            this.siticoneButton20.Visible = false;
            this.siticoneButton20.Click += new System.EventHandler(this.siticoneButton20_Click);
            // 
            // gunaLineTextBox29
            // 
            this.gunaLineTextBox29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox29.Animated = true;
            this.gunaLineTextBox29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox29.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox29.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox29.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox29.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox29.LineSize = 1;
            this.gunaLineTextBox29.Location = new System.Drawing.Point(14, 485);
            this.gunaLineTextBox29.MaxLength = 2147483647;
            this.gunaLineTextBox29.Name = "gunaLineTextBox29";
            this.gunaLineTextBox29.PasswordChar = '\0';
            this.gunaLineTextBox29.Size = new System.Drawing.Size(291, 26);
            this.gunaLineTextBox29.TabIndex = 35;
            this.gunaLineTextBox29.Text = "Insert the new custom status here.";
            this.gunaLineTextBox29.TextOffsetX = 0;
            this.gunaLineTextBox29.Visible = false;
            // 
            // siticoneButton19
            // 
            this.siticoneButton19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton19.BorderRadius = 15;
            this.siticoneButton19.CheckedState.Parent = this.siticoneButton19;
            this.siticoneButton19.CustomImages.Parent = this.siticoneButton19;
            this.siticoneButton19.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton19.ForeColor = System.Drawing.Color.White;
            this.siticoneButton19.HoveredState.Parent = this.siticoneButton19;
            this.siticoneButton19.Location = new System.Drawing.Point(14, 434);
            this.siticoneButton19.Name = "siticoneButton19";
            this.siticoneButton19.ShadowDecoration.Parent = this.siticoneButton19;
            this.siticoneButton19.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton19.TabIndex = 34;
            this.siticoneButton19.Text = "Set new game for all tokens";
            this.siticoneButton19.Visible = false;
            this.siticoneButton19.Click += new System.EventHandler(this.siticoneButton19_Click);
            // 
            // gunaLineTextBox28
            // 
            this.gunaLineTextBox28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox28.Animated = true;
            this.gunaLineTextBox28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox28.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox28.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox28.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox28.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox28.LineSize = 1;
            this.gunaLineTextBox28.Location = new System.Drawing.Point(14, 402);
            this.gunaLineTextBox28.MaxLength = 2147483647;
            this.gunaLineTextBox28.Name = "gunaLineTextBox28";
            this.gunaLineTextBox28.PasswordChar = '\0';
            this.gunaLineTextBox28.Size = new System.Drawing.Size(291, 26);
            this.gunaLineTextBox28.TabIndex = 33;
            this.gunaLineTextBox28.Text = "Insert the new game here.";
            this.gunaLineTextBox28.TextOffsetX = 0;
            this.gunaLineTextBox28.Visible = false;
            // 
            // siticoneButton18
            // 
            this.siticoneButton18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton18.BorderRadius = 15;
            this.siticoneButton18.CheckedState.Parent = this.siticoneButton18;
            this.siticoneButton18.CustomImages.Parent = this.siticoneButton18;
            this.siticoneButton18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton18.ForeColor = System.Drawing.Color.White;
            this.siticoneButton18.HoveredState.Parent = this.siticoneButton18;
            this.siticoneButton18.Location = new System.Drawing.Point(14, 337);
            this.siticoneButton18.Name = "siticoneButton18";
            this.siticoneButton18.ShadowDecoration.Parent = this.siticoneButton18;
            this.siticoneButton18.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton18.TabIndex = 32;
            this.siticoneButton18.Text = "Phone Lock all loaded tokens";
            this.siticoneButton18.Click += new System.EventHandler(this.siticoneButton18_Click);
            // 
            // siticoneButton15
            // 
            this.siticoneButton15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton15.BorderRadius = 15;
            this.siticoneButton15.CheckedState.Parent = this.siticoneButton15;
            this.siticoneButton15.CustomImages.Parent = this.siticoneButton15;
            this.siticoneButton15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton15.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton15.ForeColor = System.Drawing.Color.White;
            this.siticoneButton15.HoveredState.Parent = this.siticoneButton15;
            this.siticoneButton15.Location = new System.Drawing.Point(615, 223);
            this.siticoneButton15.Name = "siticoneButton15";
            this.siticoneButton15.ShadowDecoration.Parent = this.siticoneButton15;
            this.siticoneButton15.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton15.TabIndex = 31;
            this.siticoneButton15.Text = "Import roles from file";
            this.siticoneButton15.Click += new System.EventHandler(this.siticoneButton15_Click);
            // 
            // siticoneButton16
            // 
            this.siticoneButton16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton16.BorderRadius = 15;
            this.siticoneButton16.CheckedState.Parent = this.siticoneButton16;
            this.siticoneButton16.CustomImages.Parent = this.siticoneButton16;
            this.siticoneButton16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton16.ForeColor = System.Drawing.Color.White;
            this.siticoneButton16.HoveredState.Parent = this.siticoneButton16;
            this.siticoneButton16.Location = new System.Drawing.Point(615, 172);
            this.siticoneButton16.Name = "siticoneButton16";
            this.siticoneButton16.ShadowDecoration.Parent = this.siticoneButton16;
            this.siticoneButton16.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton16.TabIndex = 30;
            this.siticoneButton16.Text = "Export roles list to file";
            this.siticoneButton16.Click += new System.EventHandler(this.siticoneButton16_Click);
            // 
            // metroLabel33
            // 
            this.metroLabel33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel33.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel33.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel33.Location = new System.Drawing.Point(615, 147);
            this.metroLabel33.Name = "metroLabel33";
            this.metroLabel33.Size = new System.Drawing.Size(291, 19);
            this.metroLabel33.TabIndex = 29;
            this.metroLabel33.Text = "0";
            this.metroLabel33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel34
            // 
            this.metroLabel34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel34.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel34.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel34.Location = new System.Drawing.Point(612, 126);
            this.metroLabel34.Name = "metroLabel34";
            this.metroLabel34.Size = new System.Drawing.Size(294, 19);
            this.metroLabel34.TabIndex = 28;
            this.metroLabel34.Text = "Parsed Roles";
            this.metroLabel34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // siticoneButton17
            // 
            this.siticoneButton17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton17.BorderRadius = 15;
            this.siticoneButton17.CheckedState.Parent = this.siticoneButton17;
            this.siticoneButton17.CustomImages.Parent = this.siticoneButton17;
            this.siticoneButton17.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton17.ForeColor = System.Drawing.Color.White;
            this.siticoneButton17.HoveredState.Parent = this.siticoneButton17;
            this.siticoneButton17.Location = new System.Drawing.Point(615, 72);
            this.siticoneButton17.Name = "siticoneButton17";
            this.siticoneButton17.ShadowDecoration.Parent = this.siticoneButton17;
            this.siticoneButton17.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton17.TabIndex = 27;
            this.siticoneButton17.Text = "Parse Roles for this guild";
            this.siticoneButton17.Click += new System.EventHandler(this.siticoneButton17_Click);
            // 
            // gunaLineTextBox27
            // 
            this.gunaLineTextBox27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox27.Animated = true;
            this.gunaLineTextBox27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox27.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox27.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox27.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox27.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox27.LineSize = 1;
            this.gunaLineTextBox27.Location = new System.Drawing.Point(615, 40);
            this.gunaLineTextBox27.MaxLength = 2147483647;
            this.gunaLineTextBox27.Name = "gunaLineTextBox27";
            this.gunaLineTextBox27.PasswordChar = '\0';
            this.gunaLineTextBox27.Size = new System.Drawing.Size(291, 26);
            this.gunaLineTextBox27.TabIndex = 25;
            this.gunaLineTextBox27.Text = "Insert the guild ID here.";
            this.gunaLineTextBox27.TextOffsetX = 0;
            // 
            // siticoneButton14
            // 
            this.siticoneButton14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton14.BorderRadius = 15;
            this.siticoneButton14.CheckedState.Parent = this.siticoneButton14;
            this.siticoneButton14.CustomImages.Parent = this.siticoneButton14;
            this.siticoneButton14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton14.ForeColor = System.Drawing.Color.White;
            this.siticoneButton14.HoveredState.Parent = this.siticoneButton14;
            this.siticoneButton14.Location = new System.Drawing.Point(14, 258);
            this.siticoneButton14.Name = "siticoneButton14";
            this.siticoneButton14.ShadowDecoration.Parent = this.siticoneButton14;
            this.siticoneButton14.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton14.TabIndex = 24;
            this.siticoneButton14.Text = "Import users from file";
            this.siticoneButton14.Click += new System.EventHandler(this.siticoneButton14_Click);
            // 
            // siticoneButton13
            // 
            this.siticoneButton13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton13.BorderRadius = 15;
            this.siticoneButton13.CheckedState.Parent = this.siticoneButton13;
            this.siticoneButton13.CustomImages.Parent = this.siticoneButton13;
            this.siticoneButton13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton13.ForeColor = System.Drawing.Color.White;
            this.siticoneButton13.HoveredState.Parent = this.siticoneButton13;
            this.siticoneButton13.Location = new System.Drawing.Point(14, 207);
            this.siticoneButton13.Name = "siticoneButton13";
            this.siticoneButton13.ShadowDecoration.Parent = this.siticoneButton13;
            this.siticoneButton13.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton13.TabIndex = 23;
            this.siticoneButton13.Text = "Export users list to file";
            this.siticoneButton13.Click += new System.EventHandler(this.siticoneButton13_Click);
            // 
            // metroLabel32
            // 
            this.metroLabel32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel32.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel32.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel32.Location = new System.Drawing.Point(14, 182);
            this.metroLabel32.Name = "metroLabel32";
            this.metroLabel32.Size = new System.Drawing.Size(291, 19);
            this.metroLabel32.TabIndex = 22;
            this.metroLabel32.Text = "0";
            this.metroLabel32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel31
            // 
            this.metroLabel31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel31.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel31.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel31.Location = new System.Drawing.Point(11, 161);
            this.metroLabel31.Name = "metroLabel31";
            this.metroLabel31.Size = new System.Drawing.Size(294, 19);
            this.metroLabel31.TabIndex = 21;
            this.metroLabel31.Text = "Parsed Users";
            this.metroLabel31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // siticoneButton10
            // 
            this.siticoneButton10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneButton10.BorderRadius = 15;
            this.siticoneButton10.CheckedState.Parent = this.siticoneButton10;
            this.siticoneButton10.CustomImages.Parent = this.siticoneButton10;
            this.siticoneButton10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneButton10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton10.ForeColor = System.Drawing.Color.White;
            this.siticoneButton10.HoveredState.Parent = this.siticoneButton10;
            this.siticoneButton10.Location = new System.Drawing.Point(14, 107);
            this.siticoneButton10.Name = "siticoneButton10";
            this.siticoneButton10.ShadowDecoration.Parent = this.siticoneButton10;
            this.siticoneButton10.Size = new System.Drawing.Size(291, 45);
            this.siticoneButton10.TabIndex = 20;
            this.siticoneButton10.Text = "Parse Users for this guild";
            this.siticoneButton10.Click += new System.EventHandler(this.siticoneButton10_Click);
            // 
            // gunaLineTextBox24
            // 
            this.gunaLineTextBox24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox24.Animated = true;
            this.gunaLineTextBox24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox24.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox24.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox24.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox24.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox24.LineSize = 1;
            this.gunaLineTextBox24.Location = new System.Drawing.Point(14, 72);
            this.gunaLineTextBox24.MaxLength = 2147483647;
            this.gunaLineTextBox24.Name = "gunaLineTextBox24";
            this.gunaLineTextBox24.PasswordChar = '\0';
            this.gunaLineTextBox24.Size = new System.Drawing.Size(291, 26);
            this.gunaLineTextBox24.TabIndex = 9;
            this.gunaLineTextBox24.Text = "Insert the channel ID here.";
            this.gunaLineTextBox24.TextOffsetX = 0;
            // 
            // gunaLineTextBox25
            // 
            this.gunaLineTextBox25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLineTextBox25.Animated = true;
            this.gunaLineTextBox25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox25.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox25.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox25.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox25.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox25.LineSize = 1;
            this.gunaLineTextBox25.Location = new System.Drawing.Point(14, 40);
            this.gunaLineTextBox25.MaxLength = 2147483647;
            this.gunaLineTextBox25.Name = "gunaLineTextBox25";
            this.gunaLineTextBox25.PasswordChar = '\0';
            this.gunaLineTextBox25.Size = new System.Drawing.Size(291, 26);
            this.gunaLineTextBox25.TabIndex = 8;
            this.gunaLineTextBox25.Text = "Insert the guild invite link / code here.";
            this.gunaLineTextBox25.TextOffsetX = 0;
            // 
            // metroLabel29
            // 
            this.metroLabel29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel29.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel29.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel29.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(931, 23);
            this.metroLabel29.TabIndex = 2;
            this.metroLabel29.Text = "Miscellaneous";
            this.metroLabel29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage13
            // 
            this.tabPage13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage13.Controls.Add(this.metroLabel24);
            this.tabPage13.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage13.Location = new System.Drawing.Point(184, 4);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(931, 581);
            this.tabPage13.TabIndex = 13;
            this.tabPage13.Text = "Tokens Utils";
            // 
            // metroLabel24
            // 
            this.metroLabel24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel24.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel24.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel24.Location = new System.Drawing.Point(-1, 8);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(931, 23);
            this.metroLabel24.TabIndex = 3;
            this.metroLabel24.Text = "Tokens Utils";
            this.metroLabel24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // openFileDialog3
            // 
            this.openFileDialog3.Filter = "Text file (*.txt)|*.txt";
            this.openFileDialog3.Title = "Import users from file";
            // 
            // openFileDialog4
            // 
            this.openFileDialog4.Filter = "Text file (*.txt)|*.txt";
            this.openFileDialog4.Title = "Import roles list from file";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Text file (*.txt)|*.txt";
            this.saveFileDialog1.Title = "Export users list to file";
            // 
            // saveFileDialog2
            // 
            this.saveFileDialog2.Filter = "Text file (*.txt)|*.txt";
            this.saveFileDialog2.Title = "Export roles list to file";
            // 
            // openFileDialog5
            // 
            this.openFileDialog5.Title = "Import new avatar image from file";
            // 
            // MainForm
            // 
            this.AccentColor = System.Drawing.Color.Red;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1124, 634);
            this.Controls.Add(this.firefoxMainTabControl1);
            this.Controls.Add(this.gunaControlBox3);
            this.Controls.Add(this.gunaControlBox2);
            this.Controls.Add(this.gunaControlBox1);
            this.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.State = MetroSuite.MetroForm.FormState.Custom;
            this.Style = MetroSuite.Design.Style.Dark;
            this.Text = "AstarothSpammer XLS V1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.firefoxMainTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage13.ResumeLayout(false);
            this.ResumeLayout(false);

    }

    private Guna.UI.WinForms.GunaControlBox gunaControlBox1;
    private Guna.UI.WinForms.GunaControlBox gunaControlBox2;
    private Guna.UI.WinForms.GunaControlBox gunaControlBox3;
    private FirefoxMainTabControl firefoxMainTabControl1;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.TabPage tabPage2;
    private System.Windows.Forms.TabPage tabPage3;
    private System.Windows.Forms.TabPage tabPage4;
    private System.Windows.Forms.TabPage tabPage5;
    private System.Windows.Forms.TabPage tabPage6;
    private System.Windows.Forms.TabPage tabPage7;
    private System.Windows.Forms.TabPage tabPage9;
    private System.Windows.Forms.TabPage tabPage10;
    private System.Windows.Forms.TabPage tabPage11;
    private System.Windows.Forms.TabPage tabPage12;
    private MetroSuite.MetroLabel metroLabel1;
    private ns1.SiticoneButton siticoneButton1;
    private MetroSuite.MetroLabel metroLabel14;
    private MetroSuite.MetroLabel metroLabel13;
    private ns1.SiticoneButton siticoneButton2;
    private ns1.SiticoneButton siticoneButton3;
    private MetroSuite.MetroLabel metroLabel15;
    private MetroSuite.MetroLabel metroLabel16;
    private ns1.SiticoneButton siticoneButton4;
    private System.Windows.Forms.PictureBox pictureBox1;
    private ns1.SiticoneButton siticoneButton5;
    private ns1.SiticoneButton siticoneButton6;
    private MetroSuite.MetroLabel metroLabel2;
    private MetroSuite.MetroLabel metroLabel3;
    private MetroSuite.MetroLabel metroLabel4;
    private MetroSuite.MetroLabel metroLabel5;
    private MetroSuite.MetroLabel metroLabel6;
    private MetroSuite.MetroLabel metroLabel7;
    private MetroSuite.MetroLabel metroLabel9;
    private MetroSuite.MetroLabel metroLabel10;
    private MetroSuite.MetroLabel metroLabel11;
    private MetroSuite.MetroLabel metroLabel12;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox1;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox2;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox3;
    private ns1.SiticoneCheckBox siticoneCheckBox1;
    private ns1.SiticoneCheckBox siticoneCheckBox2;
    private ns1.SiticoneCheckBox siticoneCheckBox3;
    private ns1.SiticoneCheckBox siticoneCheckBox4;
    private MetroSuite.MetroLabel metroLabel17;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith1;
    private Guna.UI.WinForms.GunaButton gunaButton1;
    private Guna.UI.WinForms.GunaButton gunaButton2;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider1;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox5;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox4;
    private Guna.UI.WinForms.GunaTextBox gunaTextBox1;
    private ns1.SiticoneCheckBox siticoneCheckBox9;
    private ns1.SiticoneCheckBox siticoneCheckBox8;
    private ns1.SiticoneCheckBox siticoneCheckBox7;
    private MetroSuite.MetroLabel metroLabel18;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith2;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider2;
    private Guna.UI.WinForms.GunaButton gunaButton3;
    private Guna.UI.WinForms.GunaButton gunaButton4;
    private Guna.UI.WinForms.GunaTextBox gunaTextBox2;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox7;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox6;
    private ns1.SiticoneCheckBox siticoneCheckBox12;
    private ns1.SiticoneCheckBox siticoneCheckBox11;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider3;
    private Guna.UI.WinForms.GunaButton gunaButton6;
    private Guna.UI.WinForms.GunaButton gunaButton5;
    private MetroSuite.MetroLabel metroLabel19;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith3;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox8;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox10;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox9;
    private ns1.SiticoneRadioButton siticoneRadioButton2;
    private ns1.SiticoneRadioButton siticoneRadioButton1;
    private MetroSuite.MetroLabel metroLabel20;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith4;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider4;
    private Guna.UI.WinForms.GunaButton gunaButton8;
    private Guna.UI.WinForms.GunaButton gunaButton7;
    private ns1.SiticoneButton siticoneButton7;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox11;
    private ns1.SiticoneCheckBox siticoneCheckBox5;
    private MetroSuite.MetroLabel metroLabel21;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith5;
    private Guna.UI.WinForms.GunaButton gunaButton9;
    private Guna.UI.WinForms.GunaButton gunaButton10;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider5;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox12;
    private MetroSuite.MetroLabel metroLabel22;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith6;
    private ns1.SiticoneCheckBox siticoneCheckBox13;
    private Guna.UI.WinForms.GunaButton gunaButton12;
    private Guna.UI.WinForms.GunaButton gunaButton11;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider6;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox15;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox14;
    private MetroSuite.MetroLabel metroLabel26;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith10;
    private MetroSuite.MetroLabel metroLabel25;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith9;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider10;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider9;
    private ns1.SiticoneCheckBox siticoneCheckBox16;
    private ns1.SiticoneCheckBox siticoneCheckBox15;
    private ns1.SiticoneCheckBox siticoneCheckBox14;
    private ns1.SiticoneCheckBox siticoneCheckBox17;
    private ns1.SiticoneCheckBox siticoneCheckBox18;
    private ns1.SiticoneCheckBox siticoneCheckBox19;
    private ns1.SiticoneCheckBox siticoneCheckBox20;
    private ns1.SiticoneCheckBox siticoneCheckBox21;
    private Guna.UI.WinForms.GunaButton gunaButton16;
    private Guna.UI.WinForms.GunaButton gunaButton15;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox16;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox17;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox19;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox18;
    private Guna.UI.WinForms.GunaTextBox gunaTextBox3;
    private MetroSuite.MetroLabel metroLabel27;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith11;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider11;
    private Guna.UI.WinForms.GunaButton gunaButton18;
    private Guna.UI.WinForms.GunaButton gunaButton17;
    private Guna.UI.WinForms.GunaTextBox gunaTextBox4;
    private MetroSuite.MetroLabel metroLabel28;
    private ns1.SiticoneOSToggleSwith siticoneOSToggleSwith12;
    private Bunifu.UI.WinForms.BunifuHSlider bunifuHSlider12;
    private Guna.UI.WinForms.GunaButton gunaButton20;
    private Guna.UI.WinForms.GunaButton gunaButton19;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox20;
    private Guna.UI.WinForms.GunaLinkLabel gunaLinkLabel1;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox22;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox21;
    private ns1.SiticoneButton siticoneButton8;
    private ns1.SiticoneComboBox siticoneComboBox2;
    private ns1.SiticoneButton siticoneButton11;
    private ns1.SiticoneButton siticoneButton12;
    private System.Windows.Forms.OpenFileDialog openFileDialog1;
    private System.Windows.Forms.OpenFileDialog openFileDialog2;
    private ns1.SiticoneCheckBox siticoneCheckBox23;
    private ns1.SiticoneRadioButton siticoneRadioButton5;
    private ns1.SiticoneRadioButton siticoneRadioButton4;
    private ns1.SiticoneRadioButton siticoneRadioButton3;
    private ns1.SiticoneRadioButton siticoneRadioButton6;
    private ns1.SiticoneRadioButton siticoneRadioButton7;
    private ns1.SiticoneRadioButton siticoneRadioButton8;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox13;
    private Guna.UI.WinForms.GunaTextBox gunaTextBox5;
    private ns1.SiticoneCheckBox siticoneCheckBox25;
    private ns1.SiticoneCheckBox siticoneCheckBox24;
    private ns1.SiticoneCheckBox siticoneCheckBox10;
    private ns1.SiticoneCheckBox siticoneCheckBox6;
    private ns1.SiticoneCheckBox siticoneCheckBox26;
    private ns1.SiticoneComboBox siticoneComboBox1;
    private ns1.SiticoneButton siticoneButton9;
    private ns1.SiticoneCheckBox siticoneCheckBox22;
    private ns1.SiticoneCheckBox siticoneCheckBox27;
    private ns1.SiticoneRadioButton siticoneRadioButton9;
    private ns1.SiticoneRadioButton siticoneRadioButton10;
    private ns1.SiticoneRadioButton siticoneRadioButton11;
    private MetroSuite.MetroLabel metroLabel8;
    private ns1.SiticoneCheckBox siticoneCheckBox28;
    private ns1.SiticoneCheckBox siticoneCheckBox29;
    private ns1.SiticoneCheckBox siticoneCheckBox32;
    private ns1.SiticoneCheckBox siticoneCheckBox31;
    private ns1.SiticoneCheckBox siticoneCheckBox30;
    private System.Windows.Forms.TabPage tabPage8;
    private MetroSuite.MetroLabel metroLabel29;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox24;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox25;
    private ns1.SiticoneButton siticoneButton10;
    private MetroSuite.MetroLabel metroLabel32;
    private MetroSuite.MetroLabel metroLabel31;
    private ns1.SiticoneButton siticoneButton14;
    private ns1.SiticoneButton siticoneButton13;
    private ns1.SiticoneButton siticoneButton15;
    private ns1.SiticoneButton siticoneButton16;
    private MetroSuite.MetroLabel metroLabel33;
    private MetroSuite.MetroLabel metroLabel34;
    private ns1.SiticoneButton siticoneButton17;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox27;
    private ns1.SiticoneButton siticoneButton18;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox28;
    private ns1.SiticoneButton siticoneButton19;
    private ns1.SiticoneButton siticoneButton20;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox29;
    private System.Windows.Forms.PictureBox pictureBox2;
    private ns1.SiticoneButton siticoneButton21;
    private ns1.SiticoneButton siticoneButton22;
    private ns1.SiticoneCheckBox siticoneCheckBox33;
    private ns1.SiticoneCheckBox siticoneCheckBox34;
    private ns1.SiticoneCheckBox siticoneCheckBox35;
    private ns1.SiticoneCheckBox siticoneCheckBox36;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox23;
    private ns1.SiticoneCheckBox siticoneCheckBox37;
    private System.Windows.Forms.OpenFileDialog openFileDialog3;
    private System.Windows.Forms.OpenFileDialog openFileDialog4;
    private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    private System.Windows.Forms.SaveFileDialog saveFileDialog2;
    private System.Windows.Forms.OpenFileDialog openFileDialog5;
    private ns1.SiticoneButton siticoneButton23;
    private System.Windows.Forms.TabPage tabPage13;
    private MetroSuite.MetroLabel metroLabel24;
}