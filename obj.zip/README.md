# AstarothSpammerXLV9
A modern Discord server spammer (new version XLV9). MADE FOR EDUCATIONAL PURPOSE ONLY. 
